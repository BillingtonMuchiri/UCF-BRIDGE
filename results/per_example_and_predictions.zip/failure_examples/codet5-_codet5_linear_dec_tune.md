# worst 15 of 1000 test examples by sentence BLEU -- codet5->codet5 | linear | dec_tune

### sentBLEU=0.0
**pred:** `double function ( ) { return totalScores ; }`

**ref:**  `double function ( X arg0 ) { int loc0 = ids . get ( arg0 ) ; double loc1 = 0.0 ; double loc2 = 0.0 ; for ( int loc3 = 0 ; loc3 < size ; ++ loc3 ) { double loc4 = averageScoreFor ( loc3 ) ; loc1 += loc4 * scores [ loc0 ] [ loc3 ] ; loc2 += loc4 * games [ loc0 ] [ loc3 ] ; } return loc2 == 0.0 ? 0.0 :`

### sentBLEU=0.0
**pred:** `void function ( ) { }`

**ref:**  `void function ( Run < ? , ? > arg0 , SCM arg1 , TaskListener arg2 , ChangeLogSet < ? > arg3 ) { if ( arg0 instanceof AbstractBuild && arg2 instanceof BuildListener && Util . isOverridden ( SCMListener . class , getClass ( ) , "srini_string" , AbstractBuild . class , BuildListener . class , ChangeLog`

### sentBLEU=0.1
**pred:** `void function ( ) { }`

**ref:**  `void function ( ) { if ( isInputValid ( ) ) { String loc0 = mtg . generateText ( Integer . parseInt ( numWordsField . getText ( ) ) ) ; setResult ( loc0 ) ; } else { mainApp . showInputErrorDialog ( "srini_string" ) ; } }`

### sentBLEU=0.1
**pred:** `String function ( ) { return array . toString ( ) ; }`

**ref:**  `String function ( ) { int loc0 = array . length - 1 ; if ( loc0 == - 1 ) return "srini_string" ; StringBuilder loc1 = new StringBuilder ( ) ; loc1 . append ( '[' ) ; for ( int loc2 = 0 ; ; loc2 ++ ) { loc1 . append ( array [ loc2 ] ) ; if ( loc2 == loc0 ) return loc1 . append ( ']' ) . toString ( ) `

### sentBLEU=0.2
**pred:** `void function ( boolean arg0 ) { if ( ! bIgnoreCase ) { bLen = arg0 ; } }`

**ref:**  `String function ( ) { StringBuffer loc0 = new StringBuffer ( ) ; int loc1 = 0 ; for ( ; ( loc1 < iLen ) && ( iType [ loc1 ] == 0 ) ; loc1 ++ ) { loc0 . append ( cLike [ loc1 ] ) ; } if ( loc1 == 0 ) { return null ; } return loc0 . toString ( ) ; }`

### sentBLEU=0.2
**pred:** `BreadCrumbPanel function ( ) { return null ; }`

**ref:**  `BreadCrumbPanel function ( IBreadCrumbModel arg0 ) { int loc0 = arg0 . allBreadCrumbParticipants ( ) . size ( ) ; if ( loc0 > 0 ) { arg0 . setActive ( ( IBreadCrumbParticipant ) arg0 . allBreadCrumbParticipants ( ) . get ( 0 ) ) ; } return ( BreadCrumbPanel ) arg0 . getActive ( ) . getComponent ( ) `

### sentBLEU=0.3
**pred:** `String function ( ) { return "srini_string" ; }`

**ref:**  `void function ( String arg0 , String arg1 ) { try { FileWriter loc0 = new FileWriter ( arg0 ) ; loc0 . loc0 ( arg1 . toCharArray ( ) ) ; loc0 . close ( ) ; } catch ( IOException loc0 ) { loc0 . printStackTrace ( ) ; } }`

### sentBLEU=0.3
**pred:** `boolean function ( ) { return ( row != null ) ; }`

**ref:**  `boolean function ( ) { row = parser . parseNext ( ) ; if ( row == null && blockCounter + 1 >= this . csvParserVo . getBlockDetailsList ( ) . size ( ) ) { close ( ) ; return false ; } if ( row == null ) { initialize ( ) ; row = parser . parseNext ( ) ; } return true ; }`

### sentBLEU=0.4
**pred:** `CEnumConstant function ( ) { return new CEnumConstant ( name ) ; }`

**ref:**  `BIEnumeration function ( Element arg0 , BindInfo arg1 ) { return new BIEnumeration ( arg0 , new CEnumLeafInfo ( arg1 . model , null , new CClassInfoParent . Package ( arg1 . getTargetPackage ( ) ) , DOMUtil . getAttribute ( arg0 , "srini_string" ) , CBuiltinLeafInfo . STRING , buildMemberList ( arg1`

### sentBLEU=0.4
**pred:** `String function ( ) { return uriPrefix ; }`

**ref:**  `String function ( String arg0 ) { if ( ! belongsTo ( arg0 ) ) { throw new IllegalArgumentException ( String . format ( "srini_string" , arg0 , scheme ) ) ; } return arg0 . substring ( uriPrefix . length ( ) ) ; }`

### sentBLEU=0.5
**pred:** `void function ( ) { readPacketData ( ) ; }`

**ref:**  `void function ( PacketBuffer arg0 ) { arg0 . writeVarIntToBuffer ( this . entityId ) ; arg0 . writeDouble ( this . posX ) ; arg0 . writeDouble ( this . posY ) ; arg0 . writeDouble ( this . posZ ) ; arg0 . writeByte ( this . yaw ) ; arg0 . writeByte ( this . pitch ) ; arg0 . writeBoolean ( this . onG`

### sentBLEU=0.6
**pred:** `boolean function ( ) { return false ; }`

**ref:**  `void function ( long arg0 ) { if ( Quota . isViolated ( quota . getNameSpace ( ) , usage . getNameSpace ( ) , arg0 ) ) { throw new NSQuotaExceededException ( quota . getNameSpace ( ) , usage . getNameSpace ( ) + arg0 ) ; } }`

### sentBLEU=0.6
**pred:** `void function ( markupAttributes arg0 ) { write ( arg0 ) ; }`

**ref:**  `boolean function ( MarkupAttributes arg0 ) { Iterator loc0 = arg0 . getMarkupAttributeNames ( ) . iterator ( ) ; boolean loc1 = loc0 . hasNext ( ) ; while ( loc0 . hasNext ( ) ) { String loc2 = String . valueOf ( loc0 . next ( ) ) ; write ( loc2 , arg0 . getMarkupAttribute ( loc2 ) ) ; } return loc1`

### sentBLEU=0.6
**pred:** `LiveSetElement function ( ) { return current ; }`

**ref:**  `RegisterOperand function ( ) { if ( current != null ) { LiveSetElement loc0 = current ; current = current . getNext ( ) ; return loc0 . getRegisterOperand ( ) ; } else { throw new NoSuchElementException ( "srini_string" ) ; } }`

### sentBLEU=0.6
**pred:** `boolean function ( String arg0 ) { return sPermissionCheckEnabled ; }`

**ref:**  `void function ( String arg0 , List < String > arg1 ) { if ( sFileSystemOwner . equals ( arg0 ) || arg1 . contains ( sFileSystemSuperGroup ) ) { return ; } throw new AccessControlException ( ExceptionMessage . PERMISSION_DENIED . getMessage ( arg0 + "srini_string" ) ) ; }`
