# worst 15 of 1000 test examples by sentence BLEU -- plbart->plbart | linear | dec_tune

### sentBLEU=0.0
**pred:** `void function ( ) { }`

**ref:**  `void function ( CompletableFuture < ? extends T > arg0 ) { arg0 . handle ( ( value , failure ) -> { if ( failure == null ) { success ( value ) ; } else { error ( failure ) ; } return null ; } ) ; }`

### sentBLEU=0.0
**pred:** `boolean function ( ) { return bIgnoreCase ; }`

**ref:**  `String function ( ) { StringBuffer loc0 = new StringBuffer ( ) ; int loc1 = 0 ; for ( ; ( loc1 < iLen ) && ( iType [ loc1 ] == 0 ) ; loc1 ++ ) { loc0 . append ( cLike [ loc1 ] ) ; } if ( loc1 == 0 ) { return null ; } return loc0 . toString ( ) ; }`

### sentBLEU=0.0
**pred:** `String function ( ) { return array. toString ( ) ; }`

**ref:**  `String function ( ) { int loc0 = array . length - 1 ; if ( loc0 == - 1 ) return "srini_string" ; StringBuilder loc1 = new StringBuilder ( ) ; loc1 . append ( '[' ) ; for ( int loc2 = 0 ; ; loc2 ++ ) { loc1 . append ( array [ loc2 ] ) ; if ( loc2 == loc0 ) return loc1 . append ( ']' ) . toString ( ) `

### sentBLEU=0.1
**pred:** `BufferingOutputPort < TUPLE_TYPE > function ( ) { return port ; }`

**ref:**  `void function ( DefaultOutputPort < T > arg0 , final DefaultInputPort < T > arg1 ) { arg0 . setSink ( new Sink < Object > ( ) { @ Override @ SuppressWarnings ( "srini_string" ) public void put ( Object arg2 ) { LOG . debug ( "srini_string" ) ; arg1 . process ( ( T ) arg2 ) ; } @ Override public int `

### sentBLEU=0.1
**pred:** `void function ( View arg0, boolean arg1 ) { }`

**ref:**  `void function ( final ViewGroup arg0 , final boolean arg1 ) { for ( int loc0 = 0 ; loc0 < arg0 . getChildCount ( ) ; loc0 ++ ) { final View loc1 = arg0 . getChildAt ( loc0 ) ; if ( loc1 == null ) continue ; loc1 . setSelected ( arg1 ) ; if ( loc1 instanceof ViewGroup ) { setSelectedForAllChildrenRec`

### sentBLEU=0.1
**pred:** `double function ( ) { return totalScores ; }`

**ref:**  `double function ( X arg0 ) { int loc0 = ids . get ( arg0 ) ; double loc1 = 0.0 ; double loc2 = 0.0 ; for ( int loc3 = 0 ; loc3 < size ; ++ loc3 ) { double loc4 = averageScoreFor ( loc3 ) ; loc1 += loc4 * scores [ loc0 ] [ loc3 ] ; loc2 += loc4 * games [ loc0 ] [ loc3 ] ; } return loc2 == 0.0 ? 0.0 :`

### sentBLEU=0.2
**pred:** `FileTransfer function ( ) { return fileTransfer ; }`

**ref:**  `void function ( ) { try { incomingFileTransfer . close ( ) ; fileTransferOpSet . fireFileTransferRequestRejected ( new FileTransferRequestEvent ( fileTransferOpSet , this , date ) ) ; } catch ( IllegalStateException loc0 ) { if ( logger . isDebugEnabled ( ) ) logger . debug ( "srini_string" , loc0 )`

### sentBLEU=0.2
**pred:** `String function ( ) { return path. toString ( ) ; }`

**ref:**  `String function ( ) { final VirtualFile loc0 = _parent . get ( ) ; if ( loc0 == null || loc0 . getParent ( ) == null ) return "srini_string" ; else { final String loc1 = loc0 . getUnixPathWithoutContainer ( ) ; if ( loc1 . isEmpty ( ) ) return getName ( ) ; else return loc1 + VIRTUAL_FILE_SEPARATOR `

### sentBLEU=0.2
**pred:** `int function ( ) { return numberOfOwningShards ; }`

**ref:**  `int function ( ShardRoutingState ... arg0 ) { int loc0 = 0 ; for ( MutableShardRouting loc1 : this ) { for ( ShardRoutingState loc2 : arg0 ) { if ( loc1 . loc2 ( ) == loc2 ) { loc0 ++ ; } } } return loc0 ; }`

### sentBLEU=0.2
**pred:** `String function ( ) { return mBuffer. substring ( mPos ) ; }`

**ref:**  `String function ( char arg0 ) { if ( isEmpty ( ) ) { return "srini_string" ; } int loc0 = mBuffer . substring ( mPos ) . indexOf ( arg0 ) ; if ( loc0 == - 1 ) { return rest ( ) ; } else { loc0 += mPos ; String loc1 = mBuffer . substring ( mPos , loc0 ) ; mPos = loc0 + 1 ; return loc1 ; } }`

### sentBLEU=0.3
**pred:** `Transaction function ( Transaction arg0 ) { return arg0 ; }`

**ref:**  `boolean function ( final TransactionLocal arg0 , final Transaction arg1 ) { com . arjuna . ats . jta . arg1 . Transaction loc0 = ( com . arjuna . ats . jta . arg1 . Transaction ) arg1 ; if ( loc0 . isAlive ( ) ) { return ( loc0 . getTxLocalResource ( arg0 ) != null ? true : false ) ; } else { return`

### sentBLEU=0.3
**pred:** `String function ( ) { return "srini_string" ; }`

**ref:**  `void function ( String arg0 , String arg1 ) { try { FileWriter loc0 = new FileWriter ( arg0 ) ; loc0 . loc0 ( arg1 . toCharArray ( ) ) ; loc0 . close ( ) ; } catch ( IOException loc0 ) { loc0 . printStackTrace ( ) ; } }`

### sentBLEU=0.5
**pred:** `String function ( ) { return "srini_string" ; }`

**ref:**  `String function ( Number arg0 , Number arg1 , NumberFormat arg2 ) { String loc0 = null ; String loc1 = null ; synchronized ( arg2 ) { loc0 = arg2 . format ( arg0 ) ; loc1 = arg2 . format ( arg1 ) ; } return BindingMessages . formatString ( "srini_string" , new Object [ ] { loc0 , loc1 } ) ; }`

### sentBLEU=0.5
**pred:** `SaslServer function ( ) { return saslServer ; }`

**ref:**  `byte [ ] function ( byte [ ] arg0 ) { try { return saslServer != null ? saslServer . evaluateResponse ( arg0 ) : new byte [ 0 ] ; } catch ( SaslException loc2 ) { throw Throwables . propagate ( loc2 ) ; } }`

### sentBLEU=0.6
**pred:** `boolean function ( ) { return batchSize > 0 ; }`

**ref:**  `boolean function ( ) { row = parser . parseNext ( ) ; if ( row == null && blockCounter + 1 >= this . csvParserVo . getBlockDetailsList ( ) . size ( ) ) { close ( ) ; return false ; } if ( row == null ) { initialize ( ) ; row = parser . parseNext ( ) ; } return true ; }`
