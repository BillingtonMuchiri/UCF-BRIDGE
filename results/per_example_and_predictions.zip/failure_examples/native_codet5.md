# worst 15 of 1000 test examples by sentence BLEU -- native:codet5

### sentBLEU=0.0
**pred:** `double function ( ) { return scores [ 0 ] [ 0 ] ; }`

**ref:**  `double function ( X arg0 ) { int loc0 = ids . get ( arg0 ) ; double loc1 = 0.0 ; double loc2 = 0.0 ; for ( int loc3 = 0 ; loc3 < size ; ++ loc3 ) { double loc4 = averageScoreFor ( loc3 ) ; loc1 += loc4 * scores [ loc0 ] [ loc3 ] ; loc2 += loc4 * games [ loc0 ] [ loc3 ] ; } return loc2 == 0.0 ? 0.0 :`

### sentBLEU=0.1
**pred:** `void function ( ActionEvent arg0 ) { }`

**ref:**  `void function ( ) { if ( isInputValid ( ) ) { String loc0 = mtg . generateText ( Integer . parseInt ( numWordsField . getText ( ) ) ) ; setResult ( loc0 ) ; } else { mainApp . showInputErrorDialog ( "srini_string" ) ; } }`

### sentBLEU=0.1
**pred:** `String function ( ) { return randomString ( ) ; }`

**ref:**  `String function ( Random arg0 ) { int loc0 = RandomInts . randomIntBetween ( arg0 , 1 , 5 ) ; String loc1 = "srini_string" ; for ( int loc2 = 0 ; loc2 < loc0 ; loc2 ++ ) { if ( loc2 > 0 ) { loc1 += "srini_string" ; } loc1 += randomString ( arg0 ) ; } return loc1 ; }`

### sentBLEU=0.1
**pred:** `String function ( ) { return domainObjectSubPackage ; }`

**ref:**  `String function ( boolean arg0 ) { StringBuilder loc0 = new StringBuilder ( ) ; loc0 . append ( getSubPackageForClientOrSqlMap ( arg0 ) ) ; if ( stringHasValue ( domainObjectSubPackage ) ) { loc0 . append ( '.' ) ; loc0 . append ( domainObjectSubPackage ) ; } return loc0 . toString ( ) ; }`

### sentBLEU=0.1
**pred:** `void function ( ) { mRecv = 0 ; }`

**ref:**  `Request function ( Buffer arg0 , int arg1 , Datatype arg2 ) { MPI . check ( ) ; assertDirectBuffer ( arg0 ) ; Request loc0 = new Request ( imRecv ( handle , arg0 , arg1 , arg2 . handle ) ) ; loc0 . addRecvBufRef ( arg0 ) ; return loc0 ; }`

### sentBLEU=0.3
**pred:** `boolean function ( ) { return blockCounter < bufferSize ; }`

**ref:**  `boolean function ( ) { row = parser . parseNext ( ) ; if ( row == null && blockCounter + 1 >= this . csvParserVo . getBlockDetailsList ( ) . size ( ) ) { close ( ) ; return false ; } if ( row == null ) { initialize ( ) ; row = parser . parseNext ( ) ; } return true ; }`

### sentBLEU=0.3
**pred:** `void function ( ) { }`

**ref:**  `void function ( String arg0 ) { if ( myHost != null ) { myHost . showFeedback ( arg0 ) ; } else { System . out . println ( arg0 ) ; } }`

### sentBLEU=0.3
**pred:** `void function ( Level arg0 ) { LOGLEVEL = arg0 ; }`

**ref:**  `void function ( ) { if ( ADJUST_LOGLEVEL ) { logLevel = LOGGER . getLevel ( ) ; LOGGER . setLevel ( LOGLEVEL ) ; rootLogLevel = getRootLogHandler ( ) . getLevel ( ) ; LogManager . getLogManager ( ) . getLogger ( "srini_string" ) . getHandlers ( ) [ 0 ] . setLevel ( LOGLEVEL ) ; } }`

### sentBLEU=0.4
**pred:** `String function ( ) { return scheme ; }`

**ref:**  `String function ( String arg0 ) { if ( ! belongsTo ( arg0 ) ) { throw new IllegalArgumentException ( String . format ( "srini_string" , arg0 , scheme ) ) ; } return arg0 . substring ( uriPrefix . length ( ) ) ; }`

### sentBLEU=0.4
**pred:** `String function ( ) { return "srini_string" ; }`

**ref:**  `void function ( String arg0 , String arg1 ) { try { FileWriter loc0 = new FileWriter ( arg0 ) ; loc0 . loc0 ( arg1 . toCharArray ( ) ) ; loc0 . close ( ) ; } catch ( IOException loc0 ) { loc0 . printStackTrace ( ) ; } }`

### sentBLEU=0.5
**pred:** `TreePath function ( ) { return path . get ( ) ; }`

**ref:**  `String function ( ) { final VirtualFile loc0 = _parent . get ( ) ; if ( loc0 == null || loc0 . getParent ( ) == null ) return "srini_string" ; else { final String loc1 = loc0 . getUnixPathWithoutContainer ( ) ; if ( loc1 . isEmpty ( ) ) return getName ( ) ; else return loc1 + VIRTUAL_FILE_SEPARATOR `

### sentBLEU=0.6
**pred:** `LiveSetElement function ( ) { return current ; }`

**ref:**  `RegisterOperand function ( ) { if ( current != null ) { LiveSetElement loc0 = current ; current = current . getNext ( ) ; return loc0 . getRegisterOperand ( ) ; } else { throw new NoSuchElementException ( "srini_string" ) ; } }`

### sentBLEU=0.6
**pred:** `String function ( String arg0 ) { return digest ( arg0 ) ; }`

**ref:**  `String function ( OMElement arg0 ) { AXIOMXPath loc0 = new AXIOMXPath ( "srini_string" ) ; loc0 . addNamespace ( "srini_string" , "srini_string" ) ; OMElement loc1 = ( OMElement ) loc0 . selectSingleNode ( arg0 ) ; if ( loc1 != null ) { return loc1 . getText ( ) ; } else { throw new Exception ( "sri`

### sentBLEU=0.7
**pred:** `int function ( String arg0 , String arg1 ) { return arg0 . indexOf ( arg1 ) ; }`

**ref:**  `String function ( ) { StringBuffer loc0 = new StringBuffer ( ) ; int loc1 = 0 ; for ( ; ( loc1 < iLen ) && ( iType [ loc1 ] == 0 ) ; loc1 ++ ) { loc0 . append ( cLike [ loc1 ] ) ; } if ( loc1 == 0 ) { return null ; } return loc0 . toString ( ) ; }`

### sentBLEU=0.7
**pred:** `BreadCrumbPanel function ( Path arg0 ) { return getActivePanel ( arg0 ) ; }`

**ref:**  `BreadCrumbPanel function ( IBreadCrumbModel arg0 ) { int loc0 = arg0 . allBreadCrumbParticipants ( ) . size ( ) ; if ( loc0 > 0 ) { arg0 . setActive ( ( IBreadCrumbParticipant ) arg0 . allBreadCrumbParticipants ( ) . get ( 0 ) ) ; } return ( BreadCrumbPanel ) arg0 . getActive ( ) . getComponent ( ) `
