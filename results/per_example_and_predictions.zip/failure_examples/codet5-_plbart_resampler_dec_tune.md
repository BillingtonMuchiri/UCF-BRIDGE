# worst 15 of 1000 test examples by sentence BLEU -- codet5->plbart | resampler | dec_tune

### sentBLEU=0.0
**pred:** `double function ( ) { return totalScores ; }`

**ref:**  `double function ( X arg0 ) { int loc0 = ids . get ( arg0 ) ; double loc1 = 0.0 ; double loc2 = 0.0 ; for ( int loc3 = 0 ; loc3 < size ; ++ loc3 ) { double loc4 = averageScoreFor ( loc3 ) ; loc1 += loc4 * scores [ loc0 ] [ loc3 ] ; loc2 += loc4 * games [ loc0 ] [ loc3 ] ; } return loc2 == 0.0 ? 0.0 :`

### sentBLEU=0.1
**pred:** `void function ( ) { }`

**ref:**  `BIEnumeration function ( Element arg0 , BindInfo arg1 ) { return new BIEnumeration ( arg0 , new CEnumLeafInfo ( arg1 . model , null , new CClassInfoParent . Package ( arg1 . getTargetPackage ( ) ) , DOMUtil . getAttribute ( arg0 , "srini_string" ) , CBuiltinLeafInfo . STRING , buildMemberList ( arg1`

### sentBLEU=0.2
**pred:** `String function ( String arg0 ) { return generateSource ( arg0, null ) ; }`

**ref:**  `void function ( File arg0 , Map < String , ClassReader > arg1 , Filter arg2 ) { for ( Entry < String , ClassReader > loc0 : arg1 . entrySet ( ) ) { ClassReader loc1 = loc0 . getValue ( ) ; String loc2 = classNameToJavaPath ( loc1 . getClassName ( ) ) ; try ( FileWriter loc3 = createWriter ( arg0 , l`

### sentBLEU=0.2
**pred:** `void function ( final Map < String, Object > arg0 ) { }`

**ref:**  `void function ( FacesContext arg0 , UIComponent arg1 ) { ArrayList loc0 = ( ArrayList ) arg0 . getAttributes ( ) . get ( FormEndRendering . class . getName ( ) ) ; if ( loc0 != null ) { Iterator loc1 = loc0 . iterator ( ) ; while ( loc1 . hasNext ( ) ) { FormEndRenderer loc2 = ( FormEndRenderer ) lo`

### sentBLEU=0.2
**pred:** `void function ( long arg0 ) { m_ReadMs = arg0 ; }`

**ref:**  `Request function ( Buffer arg0 , int arg1 , Datatype arg2 ) { MPI . check ( ) ; assertDirectBuffer ( arg0 ) ; Request loc0 = new Request ( imRecv ( handle , arg0 , arg1 , arg2 . handle ) ) ; loc0 . addRecvBufRef ( arg0 ) ; return loc0 ; }`

### sentBLEU=0.2
**pred:** `void function ( CssParser. CssError arg0 ) { }`

**ref:**  `void function ( CssErrorCode arg0 , CssReader arg1 , Object ... arg2 ) { CssScannerException loc0 = new CssScannerException ( arg0 , CssLocation . create ( arg1 ) , arg2 ) ; errors . add ( loc0 ) ; errorListener . error ( loc0 ) ; }`

### sentBLEU=0.3
**pred:** `String function ( ) { return "srini_string" ; }`

**ref:**  `String function ( boolean arg0 ) { StringBuilder loc0 = new StringBuilder ( ) ; loc0 . append ( getSubPackageForClientOrSqlMap ( arg0 ) ) ; if ( stringHasValue ( domainObjectSubPackage ) ) { loc0 . append ( '.' ) ; loc0 . append ( domainObjectSubPackage ) ; } return loc0 . toString ( ) ; }`

### sentBLEU=0.5
**pred:** `float function ( float arg0, float arg1 ) { return arg0 - arg1 ; }`

**ref:**  `int function ( int arg0 , int arg1 , int arg2 ) { int loc0 = ( arg1 > arg2 ) ? arg2 : arg1 ; int loc1 = ( arg1 > arg2 ) ? arg1 : arg2 ; if ( arg0 < loc0 ) { arg0 = loc0 ; } else if ( arg0 > loc1 ) { arg0 = loc1 ; } return arg0 ; }`

### sentBLEU=0.5
**pred:** `void function ( ) { }`

**ref:**  `java . lang . Object function ( byte [ ] arg0 , short arg1 ) { Object loc0 = null ; if ( arg1 == maView . maSystem ) loc0 = ( Object ) maView . maHandle ; return loc0 ; }`

### sentBLEU=0.6
**pred:** `String function ( ) { return array. toString ( ). replace ( "srini_string", "srini_string" ) ; }`

**ref:**  `String function ( ) { int loc0 = array . length - 1 ; if ( loc0 == - 1 ) return "srini_string" ; StringBuilder loc1 = new StringBuilder ( ) ; loc1 . append ( '[' ) ; for ( int loc2 = 0 ; ; loc2 ++ ) { loc1 . append ( array [ loc2 ] ) ; if ( loc2 == loc0 ) return loc1 . append ( ']' ) . toString ( ) `

### sentBLEU=0.6
**pred:** `CipherSpi function ( ) { return spi ; }`

**ref:**  `T function ( Class < T > arg0 ) { if ( this . initialized == false ) { throw new InvalidParameterSpecException ( "srini_string" ) ; } return paramSpi . engineGetParameterSpec ( arg0 ) ; }`

### sentBLEU=0.6
**pred:** `String function ( ) { return _file. getPath ( ) ; }`

**ref:**  `String function ( ) { final VirtualFile loc0 = _parent . get ( ) ; if ( loc0 == null || loc0 . getParent ( ) == null ) return "srini_string" ; else { final String loc1 = loc0 . getUnixPathWithoutContainer ( ) ; if ( loc1 . isEmpty ( ) ) return getName ( ) ; else return loc1 + VIRTUAL_FILE_SEPARATOR `

### sentBLEU=0.6
**pred:** `void function ( IHighlightingProvider arg0 ) { fHighlightingProvider = arg0 ; }`

**ref:**  `void function ( ) { fPresenter = getPresenterProvider ( ) . get ( ) ; fPresenter . install ( fSourceViewer , fPresentationReconciler ) ; if ( styledTextXtextAdapter != null ) { fReconciler = reconcilerProvider . get ( ) ; fReconciler . install ( styledTextXtextAdapter , fSourceViewer , fPresenter ) `

### sentBLEU=0.8
**pred:** `E function ( ) { return null ; }`

**ref:**  `RegisterOperand function ( ) { if ( current != null ) { LiveSetElement loc0 = current ; current = current . getNext ( ) ; return loc0 . getRegisterOperand ( ) ; } else { throw new NoSuchElementException ( "srini_string" ) ; } }`

### sentBLEU=0.8
**pred:** `BrowseBack function ( ) { return null ; }`

**ref:**  `BreadCrumbPanel function ( IBreadCrumbModel arg0 ) { int loc0 = arg0 . allBreadCrumbParticipants ( ) . size ( ) ; if ( loc0 > 0 ) { arg0 . setActive ( ( IBreadCrumbParticipant ) arg0 . allBreadCrumbParticipants ( ) . get ( 0 ) ) ; } return ( BreadCrumbPanel ) arg0 . getActive ( ) . getComponent ( ) `
