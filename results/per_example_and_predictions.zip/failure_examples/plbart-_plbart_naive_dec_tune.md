# worst 15 of 1000 test examples by sentence BLEU -- plbart->plbart | naive | dec_tune

### sentBLEU=0.0
**pred:** `void function ( ) { }`

**ref:**  `void function ( Run < ? , ? > arg0 , SCM arg1 , TaskListener arg2 , ChangeLogSet < ? > arg3 ) { if ( arg0 instanceof AbstractBuild && arg2 instanceof BuildListener && Util . isOverridden ( SCMListener . class , getClass ( ) , "srini_string" , AbstractBuild . class , BuildListener . class , ChangeLog`

### sentBLEU=0.0
**pred:** `void function ( View arg0 ) { }`

**ref:**  `void function ( final ViewGroup arg0 , final boolean arg1 ) { for ( int loc0 = 0 ; loc0 < arg0 . getChildCount ( ) ; loc0 ++ ) { final View loc1 = arg0 . getChildAt ( loc0 ) ; if ( loc1 == null ) continue ; loc1 . setSelected ( arg1 ) ; if ( loc1 instanceof ViewGroup ) { setSelectedForAllChildrenRec`

### sentBLEU=0.0
**pred:** `TreePath function ( ) { return path ; }`

**ref:**  `String function ( ) { final VirtualFile loc0 = _parent . get ( ) ; if ( loc0 == null || loc0 . getParent ( ) == null ) return "srini_string" ; else { final String loc1 = loc0 . getUnixPathWithoutContainer ( ) ; if ( loc1 . isEmpty ( ) ) return getName ( ) ; else return loc1 + VIRTUAL_FILE_SEPARATOR `

### sentBLEU=0.0
**pred:** `void function ( ) { }`

**ref:**  `Request function ( Buffer arg0 , int arg1 , Datatype arg2 ) { MPI . check ( ) ; assertDirectBuffer ( arg0 ) ; Request loc0 = new Request ( imRecv ( handle , arg0 , arg1 , arg2 . handle ) ) ; loc0 . addRecvBufRef ( arg0 ) ; return loc0 ; }`

### sentBLEU=0.1
**pred:** `BufferingOutputPort < TUPLE_TYPE > function ( ) { return port ; }`

**ref:**  `void function ( DefaultOutputPort < T > arg0 , final DefaultInputPort < T > arg1 ) { arg0 . setSink ( new Sink < Object > ( ) { @ Override @ SuppressWarnings ( "srini_string" ) public void put ( Object arg2 ) { LOG . debug ( "srini_string" ) ; arg1 . process ( ( T ) arg2 ) ; } @ Override public int `

### sentBLEU=0.2
**pred:** `String function ( ) { return array [ length ]. toString ( ) ; }`

**ref:**  `String function ( ) { int loc0 = array . length - 1 ; if ( loc0 == - 1 ) return "srini_string" ; StringBuilder loc1 = new StringBuilder ( ) ; loc1 . append ( '[' ) ; for ( int loc2 = 0 ; ; loc2 ++ ) { loc1 . append ( array [ loc2 ] ) ; if ( loc2 == loc0 ) return loc1 . append ( ']' ) . toString ( ) `

### sentBLEU=0.2
**pred:** `String function ( ) { return createParseErrorMessage ( ) ; }`

**ref:**  `String function ( Number arg0 , Number arg1 , NumberFormat arg2 ) { String loc0 = null ; String loc1 = null ; synchronized ( arg2 ) { loc0 = arg2 . format ( arg0 ) ; loc1 = arg2 . format ( arg1 ) ; } return BindingMessages . formatString ( "srini_string" , new Object [ ] { loc0 , loc1 } ) ; }`

### sentBLEU=0.2
**pred:** `File function ( ) { return file ; }`

**ref:**  `void function ( ) { try { incomingFileTransfer . close ( ) ; fileTransferOpSet . fireFileTransferRequestRejected ( new FileTransferRequestEvent ( fileTransferOpSet , this , date ) ) ; } catch ( IllegalStateException loc0 ) { if ( logger . isDebugEnabled ( ) ) logger . debug ( "srini_string" , loc0 )`

### sentBLEU=0.2
**pred:** `void function ( XWindowPeer arg0 ) { }`

**ref:**  `java . lang . Object function ( byte [ ] arg0 , short arg1 ) { Object loc0 = null ; if ( arg1 == maView . maSystem ) loc0 = ( Object ) maView . maHandle ; return loc0 ; }`

### sentBLEU=0.2
**pred:** `boolean function ( ) { return sPermissionCheckEnabled ; }`

**ref:**  `void function ( String arg0 , List < String > arg1 ) { if ( sFileSystemOwner . equals ( arg0 ) || arg1 . contains ( sFileSystemSuperGroup ) ) { return ; } throw new AccessControlException ( ExceptionMessage . PERMISSION_DENIED . getMessage ( arg0 + "srini_string" ) ) ; }`

### sentBLEU=0.2
**pred:** `CssErrorHandler function ( ) { return errorListener ; }`

**ref:**  `void function ( CssErrorCode arg0 , CssReader arg1 , Object ... arg2 ) { CssScannerException loc0 = new CssScannerException ( arg0 , CssLocation . create ( arg1 ) , arg2 ) ; errors . add ( loc0 ) ; errorListener . error ( loc0 ) ; }`

### sentBLEU=0.2
**pred:** `int function ( ) { return executeSapp7Command ( ) ; }`

**ref:**  `void function ( String arg0 , int arg1 , int arg2 , int arg3 ) { synchronized ( this ) { SappCommand loc0 = new Sapp7DCommand ( arg2 , arg3 ) ; loc0 . run ( arg0 , arg1 ) ; if ( ! loc0 . isResponseOk ( ) ) { throw new SappException ( "srini_string" ) ; } } }`

### sentBLEU=0.2
**pred:** `TypeUse function ( ) { return xducer ; }`

**ref:**  `BIEnumeration function ( Element arg0 , BindInfo arg1 ) { return new BIEnumeration ( arg0 , new CEnumLeafInfo ( arg1 . model , null , new CClassInfoParent . Package ( arg1 . getTargetPackage ( ) ) , DOMUtil . getAttribute ( arg0 , "srini_string" ) , CBuiltinLeafInfo . STRING , buildMemberList ( arg1`

### sentBLEU=0.3
**pred:** `CertPathValidatorSpi function ( ) { return validatorSpi ; }`

**ref:**  `CertPathValidator function ( String arg0 , String arg1 ) { if ( arg1 == null ) throw new IllegalArgumentException ( "srini_string" ) ; Provider loc0 = Security . getProvider ( arg1 ) ; if ( loc0 == null ) throw new NoSuchProviderException ( arg1 ) ; return getInstance ( arg0 , loc0 ) ; }`

### sentBLEU=0.4
**pred:** `void function ( Object arg0 ) { write ( arg0 ) ; }`

**ref:**  `boolean function ( MarkupAttributes arg0 ) { Iterator loc0 = arg0 . getMarkupAttributeNames ( ) . iterator ( ) ; boolean loc1 = loc0 . hasNext ( ) ; while ( loc0 . hasNext ( ) ) { String loc2 = String . valueOf ( loc0 . next ( ) ) ; write ( loc2 , arg0 . getMarkupAttribute ( loc2 ) ) ; } return loc1`
