# worst 15 of 1000 test examples by sentence BLEU -- native:plbart

### sentBLEU=0.1
**pred:** `double function ( ) { return totalScores [ 0 ] ; }`

**ref:**  `double function ( X arg0 ) { int loc0 = ids . get ( arg0 ) ; double loc1 = 0.0 ; double loc2 = 0.0 ; for ( int loc3 = 0 ; loc3 < size ; ++ loc3 ) { double loc4 = averageScoreFor ( loc3 ) ; loc1 += loc4 * scores [ loc0 ] [ loc3 ] ; loc2 += loc4 * games [ loc0 ] [ loc3 ] ; } return loc2 == 0.0 ? 0.0 :`

### sentBLEU=0.1
**pred:** `BufferingOutputPort < TUPLE_TYPE > function ( ) { return port ; }`

**ref:**  `void function ( DefaultOutputPort < T > arg0 , final DefaultInputPort < T > arg1 ) { arg0 . setSink ( new Sink < Object > ( ) { @ Override @ SuppressWarnings ( "srini_string" ) public void put ( Object arg2 ) { LOG . debug ( "srini_string" ) ; arg1 . process ( ( T ) arg2 ) ; } @ Override public int `

### sentBLEU=0.1
**pred:** `String function ( ) { return getUnixPathWithContainer ( ) ; }`

**ref:**  `String function ( ) { final VirtualFile loc0 = _parent . get ( ) ; if ( loc0 == null || loc0 . getParent ( ) == null ) return "srini_string" ; else { final String loc1 = loc0 . getUnixPathWithoutContainer ( ) ; if ( loc1 . isEmpty ( ) ) return getName ( ) ; else return loc1 + VIRTUAL_FILE_SEPARATOR `

### sentBLEU=0.2
**pred:** `File function ( ) { return file ; }`

**ref:**  `void function ( ) { try { incomingFileTransfer . close ( ) ; fileTransferOpSet . fireFileTransferRequestRejected ( new FileTransferRequestEvent ( fileTransferOpSet , this , date ) ) ; } catch ( IllegalStateException loc0 ) { if ( logger . isDebugEnabled ( ) ) logger . debug ( "srini_string" , loc0 )`

### sentBLEU=0.3
**pred:** `boolean function ( FilePath arg0, SCM arg1, boolean arg2 ) { return false ; }`

**ref:**  `void function ( Run < ? , ? > arg0 , SCM arg1 , TaskListener arg2 , ChangeLogSet < ? > arg3 ) { if ( arg0 instanceof AbstractBuild && arg2 instanceof BuildListener && Util . isOverridden ( SCMListener . class , getClass ( ) , "srini_string" , AbstractBuild . class , BuildListener . class , ChangeLog`

### sentBLEU=0.4
**pred:** `boolean function ( ) { return mEventsAdded == 0 ; }`

**ref:**  `SchedulableEvent function ( long arg0 ) { SchedulableEvent loc0 = null ; synchronized ( lock ) { if ( ! mEventBuffer . isEmpty ( ) ) { long loc1 = mEventBuffer . firstKey ( ) ; if ( loc1 <= arg0 ) { loc0 = removeNextEventLocked ( loc1 ) ; } } } return loc0 ; }`

### sentBLEU=0.5
**pred:** `void function ( ) { playerIsKi = true ; }`

**ref:**  `void function ( String arg0 ) { int loc0 = Integer . parseInt ( arg0 ) ; this . player = loc0 ; this . optionsView . setPlayerCount ( loc0 ) ; if ( loc0 != 0 ) { this . playerIsKi = new boolean [ loc0 - 1 ] ; } this . optionsView . setPlayerToggle ( loc0 ) ; }`

### sentBLEU=0.6
**pred:** `boolean function ( String arg0 ) { return compareAt ( arg0, 0 ) ; }`

**ref:**  `String function ( ) { StringBuffer loc0 = new StringBuffer ( ) ; int loc1 = 0 ; for ( ; ( loc1 < iLen ) && ( iType [ loc1 ] == 0 ) ; loc1 ++ ) { loc0 . append ( cLike [ loc1 ] ) ; } if ( loc1 == 0 ) { return null ; } return loc0 . toString ( ) ; }`

### sentBLEU=0.7
**pred:** `List < SpringPersistenceUnitInfo > function ( ) { return readPersistenceUnitInfos ( MAPPING_FILE_NAME ) ; }`

**ref:**  `void function ( Element arg0 , SpringPersistenceUnitInfo arg1 ) { List < Element > loc0 = DomUtils . getChildElementsByTagName ( arg0 , MAPPING_FILE_NAME ) ; for ( Element loc1 : loc0 ) { String loc2 = DomUtils . getTextValue ( loc1 ) . trim ( ) ; if ( StringUtils . hasText ( loc2 ) ) { arg1 . addMa`

### sentBLEU=0.8
**pred:** `void function ( ) { }`

**ref:**  `Request function ( Buffer arg0 , int arg1 , Datatype arg2 ) { MPI . check ( ) ; assertDirectBuffer ( arg0 ) ; Request loc0 = new Request ( imRecv ( handle , arg0 , arg1 , arg2 . handle ) ) ; loc0 . addRecvBufRef ( arg0 ) ; return loc0 ; }`

### sentBLEU=0.9
**pred:** `void function ( Item arg0 ) { this. next = arg0 ; }`

**ref:**  `void function ( String arg0 , String arg1 , int arg2 ) { this . type = ClassWriter . INDY ; this . longVal = arg2 ; this . strVal1 = arg0 ; this . strVal2 = arg1 ; this . hashCode = 0x7FFFFFFF & ( ClassWriter . INDY + arg2 * strVal1 . hashCode ( ) * strVal2 . hashCode ( ) ) ; }`

### sentBLEU=1.0
**pred:** `void function ( Renderers arg0 ) { }`

**ref:**  `void function ( FacesContext arg0 , UIComponent arg1 ) { ArrayList loc0 = ( ArrayList ) arg0 . getAttributes ( ) . get ( FormEndRendering . class . getName ( ) ) ; if ( loc0 != null ) { Iterator loc1 = loc0 . iterator ( ) ; while ( loc1 . hasNext ( ) ) { FormEndRenderer loc2 = ( FormEndRenderer ) lo`

### sentBLEU=1.1
**pred:** `String function ( String arg0 ) { return DigestUtils. md5 ( arg0 ) ; }`

**ref:**  `String function ( OMElement arg0 ) { AXIOMXPath loc0 = new AXIOMXPath ( "srini_string" ) ; loc0 . addNamespace ( "srini_string" , "srini_string" ) ; OMElement loc1 = ( OMElement ) loc0 . selectSingleNode ( arg0 ) ; if ( loc1 != null ) { return loc1 . getText ( ) ; } else { throw new Exception ( "sri`

### sentBLEU=1.1
**pred:** `Result function ( ) { return stream ( ). get ( ) ; }`

**ref:**  `Result function ( ) { ResponseMessage loc0 = responseQueue . poll ( ) ; if ( loc0 != null ) return new Result ( loc0 ) ; awaitItems ( 1 ) . join ( ) ; loc0 = responseQueue . poll ( ) ; if ( loc0 != null ) return new Result ( loc0 ) ; else return null ; }`

### sentBLEU=1.1
**pred:** `boolean function ( Transaction arg0 ) { return ( arg0 instanceof LocalTransaction ) ; }`

**ref:**  `boolean function ( final TransactionLocal arg0 , final Transaction arg1 ) { com . arjuna . ats . jta . arg1 . Transaction loc0 = ( com . arjuna . ats . jta . arg1 . Transaction ) arg1 ; if ( loc0 . isAlive ( ) ) { return ( loc0 . getTxLocalResource ( arg0 ) != null ? true : false ) ; } else { return`
