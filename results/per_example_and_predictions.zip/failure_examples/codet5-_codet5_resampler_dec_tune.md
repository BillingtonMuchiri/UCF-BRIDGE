# worst 15 of 1000 test examples by sentence BLEU -- codet5->codet5 | resampler | dec_tune

### sentBLEU=0.0
**pred:** `double function ( ) { return totalScores ; }`

**ref:**  `double function ( X arg0 ) { int loc0 = ids . get ( arg0 ) ; double loc1 = 0.0 ; double loc2 = 0.0 ; for ( int loc3 = 0 ; loc3 < size ; ++ loc3 ) { double loc4 = averageScoreFor ( loc3 ) ; loc1 += loc4 * scores [ loc0 ] [ loc3 ] ; loc2 += loc4 * games [ loc0 ] [ loc3 ] ; } return loc2 == 0.0 ? 0.0 :`

### sentBLEU=0.0
**pred:** `void function ( ) { }`

**ref:**  `void function ( ) { Subscriber < String > loc0 = new TestSubscriber < String > ( ) ; final AtomicLong loc1 = new AtomicLong ( ) ; loc0 . setProducer ( new Producer ( ) { @ Override public void request ( long arg0 ) { loc1 . set ( arg0 ) ; } } ) ; assertEquals ( Long . MAX_VALUE , loc1 . get ( ) ) ; `

### sentBLEU=0.0
**pred:** `void function ( ) { }`

**ref:**  `void function ( FacesContext arg0 , UIComponent arg1 ) { ArrayList loc0 = ( ArrayList ) arg0 . getAttributes ( ) . get ( FormEndRendering . class . getName ( ) ) ; if ( loc0 != null ) { Iterator loc1 = loc0 . iterator ( ) ; while ( loc1 . hasNext ( ) ) { FormEndRenderer loc2 = ( FormEndRenderer ) lo`

### sentBLEU=0.0
**pred:** `boolean function ( ) { return true ; }`

**ref:**  `String function ( ) { StringBuffer loc0 = new StringBuffer ( ) ; int loc1 = 0 ; for ( ; ( loc1 < iLen ) && ( iType [ loc1 ] == 0 ) ; loc1 ++ ) { loc0 . append ( cLike [ loc1 ] ) ; } if ( loc1 == 0 ) { return null ; } return loc0 . toString ( ) ; }`

### sentBLEU=0.0
**pred:** `void function ( ) { }`

**ref:**  `boolean function ( ) { if ( ! doneAdding || cleanedUp ) { throw new IllegalStateException ( ) ; } if ( this . ramValues != null ) { return this . iterationIndex < numValuesInRam ; } else { return ! priorityQueue . isEmpty ( ) ; } }`

### sentBLEU=0.1
**pred:** `void function ( ) { mProbe = null ; }`

**ref:**  `Request function ( Buffer arg0 , int arg1 , Datatype arg2 ) { MPI . check ( ) ; assertDirectBuffer ( arg0 ) ; Request loc0 = new Request ( imRecv ( handle , arg0 , arg1 , arg2 . handle ) ) ; loc0 . addRecvBufRef ( arg0 ) ; return loc0 ; }`

### sentBLEU=0.1
**pred:** `void function ( ActionEvent arg0 ) { }`

**ref:**  `void function ( ) { if ( isInputValid ( ) ) { String loc0 = mtg . generateText ( Integer . parseInt ( numWordsField . getText ( ) ) ) ; setResult ( loc0 ) ; } else { mainApp . showInputErrorDialog ( "srini_string" ) ; } }`

### sentBLEU=0.1
**pred:** `boolean function ( ) { return false ; }`

**ref:**  `void function ( long arg0 ) { if ( Quota . isViolated ( quota . getNameSpace ( ) , usage . getNameSpace ( ) , arg0 ) ) { throw new NSQuotaExceededException ( quota . getNameSpace ( ) , usage . getNameSpace ( ) + arg0 ) ; } }`

### sentBLEU=0.1
**pred:** `String function ( ) { return "srini_string" ; }`

**ref:**  `String function ( Random arg0 ) { int loc0 = RandomInts . randomIntBetween ( arg0 , 1 , 5 ) ; String loc1 = "srini_string" ; for ( int loc2 = 0 ; loc2 < loc0 ; loc2 ++ ) { if ( loc2 > 0 ) { loc1 += "srini_string" ; } loc1 += randomString ( arg0 ) ; } return loc1 ; }`

### sentBLEU=0.2
**pred:** `FourierMatrix function ( FourierMatrix arg0 , FourierMatrix arg1 ) { return new FourierMatrix ( arg0 , arg1 ) ; }`

**ref:**  `Fraction [ ] [ ] function ( int arg0 , int arg1 , Fraction arg2 ) { Fraction [ ] [ ] loc0 = new Fraction [ arg0 ] [ arg1 ] ; for ( int loc1 = 0 ; loc1 < arg0 ; loc1 ++ ) { for ( int loc2 = 0 ; loc2 < arg1 ; loc2 ++ ) { loc0 [ loc1 ] [ loc2 ] = arg2 ; } } return loc0 ; }`

### sentBLEU=0.2
**pred:** `CEnumConstant function ( ) { return new CEnumConstant ( ) ; }`

**ref:**  `BIEnumeration function ( Element arg0 , BindInfo arg1 ) { return new BIEnumeration ( arg0 , new CEnumLeafInfo ( arg1 . model , null , new CClassInfoParent . Package ( arg1 . getTargetPackage ( ) ) , DOMUtil . getAttribute ( arg0 , "srini_string" ) , CBuiltinLeafInfo . STRING , buildMemberList ( arg1`

### sentBLEU=0.2
**pred:** `void function ( boolean arg0 ) { mEnabled = arg0 ; }`

**ref:**  `void function ( ) { if ( mSensor == null ) { Log . w ( TAG , "srini_string" ) ; return ; } if ( mEnabled == false ) { if ( localLOGV ) Log . d ( TAG , "srini_string" ) ; mSensorManager . registerListener ( mSensorEventListener , mSensor , mRate ) ; mEnabled = true ; } }`

### sentBLEU=0.2
**pred:** `int function ( String arg0 ) { return javaMethod ( arg0 ) ; }`

**ref:**  `int function ( int arg0 , Class arg1 , String arg2 ) { synchronized ( LuaStateFactory . getExistingState ( arg0 ) ) { int loc0 ; loc0 = checkField ( arg0 , arg1 , arg2 ) ; if ( loc0 != 0 ) { return 1 ; } loc0 = checkMethod ( arg0 , arg1 , arg2 ) ; if ( loc0 != 0 ) { return 2 ; } return 0 ; } }`

### sentBLEU=0.3
**pred:** `void function ( ) { loopStart = loopStart ; }`

**ref:**  `void function ( Path arg0 , TransitionList arg1 ) { if ( isLooping ) return ; if ( arg0 . continuousTime ( ) ) return ; if ( ! arg1 . isDeterministic ( ) ) return ; if ( arg0 . getPreviousState ( ) . equals ( arg0 . getCurrentState ( ) ) ) { isLooping = true ; loopStart = arg0 . size ( ) - 1 ; loopE`

### sentBLEU=0.4
**pred:** `int function ( ) { return iterations ; }`

**ref:**  `int function ( CDouble arg0 ) { if ( Thread . interrupted ( ) ) { throw new InterruptedException ( ) ; } CDouble loc0 = CDouble . ZERO ; for ( int loc1 = 0 ; loc1 < maxIter ; loc1 ++ ) { loc0 = loc0 . squared ( ) . add ( arg0 ) ; if ( loc0 . abs2 ( ) > 10.0 ) return loc1 ; } return - 1 ; }`
