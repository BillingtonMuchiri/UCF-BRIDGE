# worst 15 of 1000 test examples by sentence BLEU -- codet5->codegpt | linear | dec_tune

### sentBLEU=0.0
**pred:** `double [ ] function ( ) { return totalSumSquares ; }`

**ref:**  `double function ( X arg0 ) { int loc0 = ids . get ( arg0 ) ; double loc1 = 0.0 ; double loc2 = 0.0 ; for ( int loc3 = 0 ; loc3 < size ; ++ loc3 ) { double loc4 = averageScoreFor ( loc3 ) ; loc1 += loc4 * scores [ loc0 ] [ loc3 ] ; loc2 += loc4 * games [ loc0 ] [ loc3 ] ; } return loc2 == 0.0 ? 0.0 :`

### sentBLEU=0.1
**pred:** `void function ( ) { }`

**ref:**  `java . lang . Object function ( byte [ ] arg0 , short arg1 ) { Object loc0 = null ; if ( arg1 == maView . maSystem ) loc0 = ( Object ) maView . maHandle ; return loc0 ; }`

### sentBLEU=0.1
**pred:** `void function ( ) { }`

**ref:**  `void function ( ) { if ( isInputValid ( ) ) { String loc0 = mtg . generateText ( Integer . parseInt ( numWordsField . getText ( ) ) ) ; setResult ( loc0 ) ; } else { mainApp . showInputErrorDialog ( "srini_string" ) ; } }`

### sentBLEU=0.1
**pred:** `boolean function ( ) { return mEventsAdded ; }`

**ref:**  `SchedulableEvent function ( long arg0 ) { SchedulableEvent loc0 = null ; synchronized ( lock ) { if ( ! mEventBuffer . isEmpty ( ) ) { long loc1 = mEventBuffer . firstKey ( ) ; if ( loc1 <= arg0 ) { loc0 = removeNextEventLocked ( loc1 ) ; } } } return loc0 ; }`

### sentBLEU=0.2
**pred:** `boolean function ( ) { return optionsView . isEnabled ( ) ; }`

**ref:**  `void function ( String arg0 ) { int loc0 = Integer . parseInt ( arg0 ) ; this . player = loc0 ; this . optionsView . setPlayerCount ( loc0 ) ; if ( loc0 != 0 ) { this . playerIsKi = new boolean [ loc0 - 1 ] ; } this . optionsView . setPlayerToggle ( loc0 ) ; }`

### sentBLEU=0.3
**pred:** `void function ( TikacQueryInterceptor arg0 ) { arg0 . setPort ( port ) ; }`

**ref:**  `void function ( DefaultOutputPort < T > arg0 , final DefaultInputPort < T > arg1 ) { arg0 . setSink ( new Sink < Object > ( ) { @ Override @ SuppressWarnings ( "srini_string" ) public void put ( Object arg2 ) { LOG . debug ( "srini_string" ) ; arg1 . process ( ( T ) arg2 ) ; } @ Override public int `

### sentBLEU=0.3
**pred:** `int function ( ) { return current ; }`

**ref:**  `AnyType function ( int arg0 ) { if ( arg0 < 0 || arg0 >= size ( ) ) throw new ArrayIndexOutOfBoundsException ( "srini_string" + arg0 + "srini_string" + size ( ) ) ; return theItems [ arg0 ] ; }`

### sentBLEU=0.3
**pred:** `Throwable function ( ) { return null ; }`

**ref:**  `Throwable function ( Throwable arg0 ) { Throwable loc0 = arg0 . getCause ( ) ; int loc1 = 0 ; while ( loc0 != null && ++ loc1 < 1024 ) { arg0 = loc0 ; loc0 = arg0 . getCause ( ) ; } return arg0 ; }`

### sentBLEU=0.3
**pred:** `void function ( ) { svmCamelExecutorInstance . executeSvmCommand ( ) ; }`

**ref:**  `void function ( String arg0 , int arg1 , int arg2 , int arg3 ) { synchronized ( this ) { SappCommand loc0 = new Sapp7DCommand ( arg2 , arg3 ) ; loc0 . run ( arg0 , arg1 ) ; if ( ! loc0 . isResponseOk ( ) ) { throw new SappException ( "srini_string" ) ; } } }`

### sentBLEU=0.3
**pred:** `Branch function ( ) { return getActiveBranch ( ) ; }`

**ref:**  `BreadCrumbPanel function ( IBreadCrumbModel arg0 ) { int loc0 = arg0 . allBreadCrumbParticipants ( ) . size ( ) ; if ( loc0 > 0 ) { arg0 . setActive ( ( IBreadCrumbParticipant ) arg0 . allBreadCrumbParticipants ( ) . get ( 0 ) ) ; } return ( BreadCrumbPanel ) arg0 . getActive ( ) . getComponent ( ) `

### sentBLEU=0.5
**pred:** `String function ( ) { return path . getPath ( ) ; }`

**ref:**  `String function ( ) { final VirtualFile loc0 = _parent . get ( ) ; if ( loc0 == null || loc0 . getParent ( ) == null ) return "srini_string" ; else { final String loc1 = loc0 . getUnixPathWithoutContainer ( ) ; if ( loc1 . isEmpty ( ) ) return getName ( ) ; else return loc1 + VIRTUAL_FILE_SEPARATOR `

### sentBLEU=0.5
**pred:** `void function ( ) { }`

**ref:**  `void function ( Tracker arg0 ) { String loc0 = input . ask ( "srini_string" ) ; String loc1 = input . ask ( "srini_string" ) ; String loc2 = input . ask ( "srini_string" ) ; arg0 . add ( new Task ( loc0 , loc1 , Long . parseLong ( loc2 ) ) ) ; arg0 . findAll ( ) ; }`

### sentBLEU=0.6
**pred:** `int function ( ) { return numberOfOutstandingShards ; }`

**ref:**  `int function ( ShardRoutingState ... arg0 ) { int loc0 = 0 ; for ( MutableShardRouting loc1 : this ) { for ( ShardRoutingState loc2 : arg0 ) { if ( loc1 . loc2 ( ) == loc2 ) { loc0 ++ ; } } } return loc0 ; }`

### sentBLEU=0.6
**pred:** `boolean function ( ) { return parser . isEmpty ( ) ; }`

**ref:**  `boolean function ( ) { row = parser . parseNext ( ) ; if ( row == null && blockCounter + 1 >= this . csvParserVo . getBlockDetailsList ( ) . size ( ) ) { close ( ) ; return false ; } if ( row == null ) { initialize ( ) ; row = parser . parseNext ( ) ; } return true ; }`

### sentBLEU=0.6
**pred:** `LiteralTreeNode function ( ) { return null ; }`

**ref:**  `RegisterOperand function ( ) { if ( current != null ) { LiveSetElement loc0 = current ; current = current . getNext ( ) ; return loc0 . getRegisterOperand ( ) ; } else { throw new NoSuchElementException ( "srini_string" ) ; } }`
