# worst 15 of 1000 test examples by sentence BLEU -- codet5->plbart | linear | dec_tune

### sentBLEU=0.0
**pred:** `double function ( ) { return totalScores ; }`

**ref:**  `double function ( X arg0 ) { int loc0 = ids . get ( arg0 ) ; double loc1 = 0.0 ; double loc2 = 0.0 ; for ( int loc3 = 0 ; loc3 < size ; ++ loc3 ) { double loc4 = averageScoreFor ( loc3 ) ; loc1 += loc4 * scores [ loc0 ] [ loc3 ] ; loc2 += loc4 * games [ loc0 ] [ loc3 ] ; } return loc2 == 0.0 ? 0.0 :`

### sentBLEU=0.0
**pred:** `void function ( ) { }`

**ref:**  `void function ( FacesContext arg0 , UIComponent arg1 ) { ArrayList loc0 = ( ArrayList ) arg0 . getAttributes ( ) . get ( FormEndRendering . class . getName ( ) ) ; if ( loc0 != null ) { Iterator loc1 = loc0 . iterator ( ) ; while ( loc1 . hasNext ( ) ) { FormEndRenderer loc2 = ( FormEndRenderer ) lo`

### sentBLEU=0.1
**pred:** `void function ( ) { }`

**ref:**  `java . lang . Object function ( byte [ ] arg0 , short arg1 ) { Object loc0 = null ; if ( arg1 == maView . maSystem ) loc0 = ( Object ) maView . maHandle ; return loc0 ; }`

### sentBLEU=0.3
**pred:** `String function ( ) { return "srini_string" ; }`

**ref:**  `void function ( String arg0 , String arg1 ) { try { FileWriter loc0 = new FileWriter ( arg0 ) ; loc0 . loc0 ( arg1 . toCharArray ( ) ) ; loc0 . close ( ) ; } catch ( IOException loc0 ) { loc0 . printStackTrace ( ) ; } }`

### sentBLEU=0.3
**pred:** `CEnumDecl function ( ) { return new CEnumDecl ( name, e ) ; }`

**ref:**  `BIEnumeration function ( Element arg0 , BindInfo arg1 ) { return new BIEnumeration ( arg0 , new CEnumLeafInfo ( arg1 . model , null , new CClassInfoParent . Package ( arg1 . getTargetPackage ( ) ) , DOMUtil . getAttribute ( arg0 , "srini_string" ) , CBuiltinLeafInfo . STRING , buildMemberList ( arg1`

### sentBLEU=0.4
**pred:** `int function ( ) { return ki ; }`

**ref:**  `void function ( String arg0 ) { int loc0 = Integer . parseInt ( arg0 ) ; this . player = loc0 ; this . optionsView . setPlayerCount ( loc0 ) ; if ( loc0 != 0 ) { this . playerIsKi = new boolean [ loc0 - 1 ] ; } this . optionsView . setPlayerToggle ( loc0 ) ; }`

### sentBLEU=0.6
**pred:** `boolean function ( ) { return parser. hasNext ( ) ; }`

**ref:**  `boolean function ( ) { row = parser . parseNext ( ) ; if ( row == null && blockCounter + 1 >= this . csvParserVo . getBlockDetailsList ( ) . size ( ) ) { close ( ) ; return false ; } if ( row == null ) { initialize ( ) ; row = parser . parseNext ( ) ; } return true ; }`

### sentBLEU=0.7
**pred:** `boolean function ( TransactionLocal arg0 ) { return arg0. isAttribute ( TransactionLocal. ATTR_LOCAL ) ; }`

**ref:**  `boolean function ( final TransactionLocal arg0 , final Transaction arg1 ) { com . arjuna . ats . jta . arg1 . Transaction loc0 = ( com . arjuna . ats . jta . arg1 . Transaction ) arg1 ; if ( loc0 . isAlive ( ) ) { return ( loc0 . getTxLocalResource ( arg0 ) != null ? true : false ) ; } else { return`

### sentBLEU=0.7
**pred:** `void function ( ) { }`

**ref:**  `void function ( Run < ? , ? > arg0 , SCM arg1 , TaskListener arg2 , ChangeLogSet < ? > arg3 ) { if ( arg0 instanceof AbstractBuild && arg2 instanceof BuildListener && Util . isOverridden ( SCMListener . class , getClass ( ) , "srini_string" , AbstractBuild . class , BuildListener . class , ChangeLog`

### sentBLEU=0.8
**pred:** `CertificatePathValidatorSpi function ( Provider arg0 ) { return validatorSpi ; }`

**ref:**  `CertPathValidator function ( String arg0 , String arg1 ) { if ( arg1 == null ) throw new IllegalArgumentException ( "srini_string" ) ; Provider loc0 = Security . getProvider ( arg1 ) ; if ( loc0 == null ) throw new NoSuchProviderException ( arg1 ) ; return getInstance ( arg0 , loc0 ) ; }`

### sentBLEU=0.8
**pred:** `void function ( long arg0 ) { mRecv = arg0 ; }`

**ref:**  `Request function ( Buffer arg0 , int arg1 , Datatype arg2 ) { MPI . check ( ) ; assertDirectBuffer ( arg0 ) ; Request loc0 = new Request ( imRecv ( handle , arg0 , arg1 , arg2 . handle ) ) ; loc0 . addRecvBufRef ( arg0 ) ; return loc0 ; }`

### sentBLEU=1.0
**pred:** `boolean function ( String arg0 ) { return arg0. startsWith ( "srini_string" ) ; }`

**ref:**  `boolean function ( final URL arg0 ) { if ( getPath ( arg0 ) . endsWith ( "srini_string" ) ) { return true ; } else if ( arg0 . getProtocol ( ) . equals ( "srini_string" ) ) { final File loc0 = new File ( getPath ( arg0 ) ) ; try { if ( loc0 . isDirectory ( ) ) { return true ; } } catch ( SecurityExc`

### sentBLEU=1.1
**pred:** `void function ( Item arg0 ) { this. next = arg0 ; }`

**ref:**  `void function ( String arg0 , String arg1 , int arg2 ) { this . type = ClassWriter . INDY ; this . longVal = arg2 ; this . strVal1 = arg0 ; this . strVal2 = arg1 ; this . hashCode = 0x7FFFFFFF & ( ClassWriter . INDY + arg2 * strVal1 . hashCode ( ) * strVal2 . hashCode ( ) ) ; }`

### sentBLEU=1.1
**pred:** `String function ( String arg0 ) { return arg0 + "srini_string" ; }`

**ref:**  `String function ( Random arg0 ) { int loc0 = RandomInts . randomIntBetween ( arg0 , 1 , 5 ) ; String loc1 = "srini_string" ; for ( int loc2 = 0 ; loc2 < loc0 ; loc2 ++ ) { if ( loc2 > 0 ) { loc1 += "srini_string" ; } loc1 += randomString ( arg0 ) ; } return loc1 ; }`

### sentBLEU=1.1
**pred:** `void function ( ) { pos = pos + 1 ; }`

**ref:**  `void function ( int arg0 ) { if ( arg0 > this . s . length ( ) - 1 ) { throw new IndexOutOfBoundsException ( "srini_string" + arg0 + "srini_string" ) ; } this . pos = arg0 ; }`
