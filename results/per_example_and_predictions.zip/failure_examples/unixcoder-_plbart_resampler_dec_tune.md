# worst 15 of 1000 test examples by sentence BLEU -- unixcoder->plbart | resampler | dec_tune

### sentBLEU=0.0
**pred:** `void function ( ) { }`

**ref:**  `void function ( Path arg0 , TransitionList arg1 ) { if ( isLooping ) return ; if ( arg0 . continuousTime ( ) ) return ; if ( ! arg1 . isDeterministic ( ) ) return ; if ( arg0 . getPreviousState ( ) . equals ( arg0 . getCurrentState ( ) ) ) { isLooping = true ; loopStart = arg0 . size ( ) - 1 ; loopE`

### sentBLEU=0.0
**pred:** `double function ( double arg0 ) { return arg0 * this. score ; }`

**ref:**  `double function ( X arg0 ) { int loc0 = ids . get ( arg0 ) ; double loc1 = 0.0 ; double loc2 = 0.0 ; for ( int loc3 = 0 ; loc3 < size ; ++ loc3 ) { double loc4 = averageScoreFor ( loc3 ) ; loc1 += loc4 * scores [ loc0 ] [ loc3 ] ; loc2 += loc4 * games [ loc0 ] [ loc3 ] ; } return loc2 == 0.0 ? 0.0 :`

### sentBLEU=0.0
**pred:** `void function ( RenderedContext arg0, RenderedContext arg1 ) { }`

**ref:**  `void function ( FacesContext arg0 , UIComponent arg1 ) { ArrayList loc0 = ( ArrayList ) arg0 . getAttributes ( ) . get ( FormEndRendering . class . getName ( ) ) ; if ( loc0 != null ) { Iterator loc1 = loc0 . iterator ( ) ; while ( loc1 . hasNext ( ) ) { FormEndRenderer loc2 = ( FormEndRenderer ) lo`

### sentBLEU=0.1
**pred:** `boolean function ( ) { return m_is_mim ; }`

**ref:**  `Request function ( Buffer arg0 , int arg1 , Datatype arg2 ) { MPI . check ( ) ; assertDirectBuffer ( arg0 ) ; Request loc0 = new Request ( imRecv ( handle , arg0 , arg1 , arg2 . handle ) ) ; loc0 . addRecvBufRef ( arg0 ) ; return loc0 ; }`

### sentBLEU=0.1
**pred:** `List < String > function ( ) { return listProjects ; }`

**ref:**  `void function ( String arg0 , int arg1 , int arg2 ) { ProjectComboBO loc0 = new ProjectComboBO ( ) ; this . mtxProjectList = loc0 . getProjectComboList ( arg0 , arg1 , arg2 , LIST_ALL_PROJECT ) ; if ( this . strProjectID . length ( ) < 2 ) { this . strProjectID = this . mtxProjectList . getCell ( 0 `

### sentBLEU=0.2
**pred:** `void function ( int arg0 ) { this. cursor = arg0 ; }`

**ref:**  `void function ( double arg0 , RectangleEdge arg1 ) { if ( arg1 == RectangleEdge . TOP ) { cursorUp ( arg0 ) ; } else if ( arg1 == RectangleEdge . BOTTOM ) { cursorDown ( arg0 ) ; } else if ( arg1 == RectangleEdge . LEFT ) { cursorLeft ( arg0 ) ; } else if ( arg1 == RectangleEdge . RIGHT ) { cursorRi`

### sentBLEU=0.2
**pred:** `long function ( ) { return this. partitionOffset ; }`

**ref:**  `long function ( long arg0 , int arg1 ) { assert ( arg1 <= MAXIMUM_PARTITION_ID ) ; final long loc0 = ( arg0 & MASK_LONG_UPPER_13_BITS ) >>> 24 ; final long loc1 = loc0 | ( arg0 & MASK_LONG_LOWER_27_BITS ) ; return ( ( ( long ) arg1 ) << 40 ) | loc1 ; }`

### sentBLEU=0.3
**pred:** `T function ( ) { return this. result ; }`

**ref:**  `void function ( CompletableFuture < ? extends T > arg0 ) { arg0 . handle ( ( value , failure ) -> { if ( failure == null ) { success ( value ) ; } else { error ( failure ) ; } return null ; } ) ; }`

### sentBLEU=0.3
**pred:** `void function ( Properties arg0 ) { this. props = arg0 ; }`

**ref:**  `Prop function ( String arg0 , String arg1 ) { Prop loc0 = map . get ( arg0 ) ; if ( loc0 == null ) { loc0 = new Prop ( arg0 , arg1 ) ; map . put ( arg0 , loc0 ) ; if ( PropKit . prop == null ) PropKit . prop = loc0 ; } return loc0 ; }`

### sentBLEU=0.3
**pred:** `boolean function ( ) { return m_type == Type. STRING ; }`

**ref:**  `String function ( ) { StringBuffer loc0 = new StringBuffer ( ) ; int loc1 = 0 ; for ( ; ( loc1 < iLen ) && ( iType [ loc1 ] == 0 ) ; loc1 ++ ) { loc0 . append ( cLike [ loc1 ] ) ; } if ( loc1 == 0 ) { return null ; } return loc0 . toString ( ) ; }`

### sentBLEU=0.3
**pred:** `Provider function ( ) { return provider ; }`

**ref:**  `CertPathValidator function ( String arg0 , String arg1 ) { if ( arg1 == null ) throw new IllegalArgumentException ( "srini_string" ) ; Provider loc0 = Security . getProvider ( arg1 ) ; if ( loc0 == null ) throw new NoSuchProviderException ( arg1 ) ; return getInstance ( arg0 , loc0 ) ; }`

### sentBLEU=0.4
**pred:** `int function ( ) { return purchasedQuantity ; }`

**ref:**  `int function ( ) { Iterator loc0 = purchasedList . iterator ( ) ; int loc1 = 0 ; while ( loc0 . hasNext ( ) ) { loc1 += ( ( CartItem ) loc0 . next ( ) ) . getPurchasedQuantity ( ) ; } return ( loc1 ) ; }`

### sentBLEU=0.5
**pred:** `int function ( ) { return this. numberOfShardCopies ; }`

**ref:**  `int function ( ShardRoutingState ... arg0 ) { int loc0 = 0 ; for ( MutableShardRouting loc1 : this ) { for ( ShardRoutingState loc2 : arg0 ) { if ( loc1 . loc2 ( ) == loc2 ) { loc0 ++ ; } } } return loc0 ; }`

### sentBLEU=0.5
**pred:** `String function ( ) { return m_virtualPath ; }`

**ref:**  `String function ( ) { final VirtualFile loc0 = _parent . get ( ) ; if ( loc0 == null || loc0 . getParent ( ) == null ) return "srini_string" ; else { final String loc1 = loc0 . getUnixPathWithoutContainer ( ) ; if ( loc1 . isEmpty ( ) ) return getName ( ) ; else return loc1 + VIRTUAL_FILE_SEPARATOR `

### sentBLEU=0.5
**pred:** `Map < String, String > function ( ) { return this. authorizationMap ; }`

**ref:**  `Map < String , ? > function ( Properties arg0 , String arg1 ) { Map < String , Object > loc0 = new HashMap < String , Object > ( ) ; for ( String loc1 : arg0 . stringPropertyNames ( ) ) { if ( loc1 . startsWith ( arg1 ) ) { String loc2 = loc1 . substring ( arg1 . length ( ) ) ; loc0 . put ( loc2 , a`
