# worst 15 of 1000 test examples by sentence BLEU -- plbart->plbart | resampler | dec_tune

### sentBLEU=0.0
**pred:** `double function ( ) { return totalScores ; }`

**ref:**  `double function ( X arg0 ) { int loc0 = ids . get ( arg0 ) ; double loc1 = 0.0 ; double loc2 = 0.0 ; for ( int loc3 = 0 ; loc3 < size ; ++ loc3 ) { double loc4 = averageScoreFor ( loc3 ) ; loc1 += loc4 * scores [ loc0 ] [ loc3 ] ; loc2 += loc4 * games [ loc0 ] [ loc3 ] ; } return loc2 == 0.0 ? 0.0 :`

### sentBLEU=0.0
**pred:** `String function ( ) { return array [ 0 ] ; }`

**ref:**  `String function ( ) { int loc0 = array . length - 1 ; if ( loc0 == - 1 ) return "srini_string" ; StringBuilder loc1 = new StringBuilder ( ) ; loc1 . append ( '[' ) ; for ( int loc2 = 0 ; ; loc2 ++ ) { loc1 . append ( array [ loc2 ] ) ; if ( loc2 == loc0 ) return loc1 . append ( ']' ) . toString ( ) `

### sentBLEU=0.0
**pred:** `void function ( Renderable arg0, Renderable arg1 ) { }`

**ref:**  `void function ( FacesContext arg0 , UIComponent arg1 ) { ArrayList loc0 = ( ArrayList ) arg0 . getAttributes ( ) . get ( FormEndRendering . class . getName ( ) ) ; if ( loc0 != null ) { Iterator loc1 = loc0 . iterator ( ) ; while ( loc1 . hasNext ( ) ) { FormEndRenderer loc2 = ( FormEndRenderer ) lo`

### sentBLEU=0.1
**pred:** `boolean function ( ) { return maxIterations == 0 ; }`

**ref:**  `int function ( CDouble arg0 ) { if ( Thread . interrupted ( ) ) { throw new InterruptedException ( ) ; } CDouble loc0 = CDouble . ZERO ; for ( int loc1 = 0 ; loc1 < maxIter ; loc1 ++ ) { loc0 = loc0 . squared ( ) . add ( arg0 ) ; if ( loc0 . abs2 ( ) > 10.0 ) return loc1 ; } return - 1 ; }`

### sentBLEU=0.1
**pred:** `String function ( ) { return path ; }`

**ref:**  `String function ( ) { final VirtualFile loc0 = _parent . get ( ) ; if ( loc0 == null || loc0 . getParent ( ) == null ) return "srini_string" ; else { final String loc1 = loc0 . getUnixPathWithoutContainer ( ) ; if ( loc1 . isEmpty ( ) ) return getName ( ) ; else return loc1 + VIRTUAL_FILE_SEPARATOR `

### sentBLEU=0.1
**pred:** `String function ( ) { return m_string ; }`

**ref:**  `String function ( char arg0 ) { if ( isEmpty ( ) ) { return "srini_string" ; } int loc0 = mBuffer . substring ( mPos ) . indexOf ( arg0 ) ; if ( loc0 == - 1 ) { return rest ( ) ; } else { loc0 += mPos ; String loc1 = mBuffer . substring ( mPos , loc0 ) ; mPos = loc0 + 1 ; return loc1 ; } }`

### sentBLEU=0.1
**pred:** `boolean function ( ) { return bIsCompound ; }`

**ref:**  `String function ( ) { StringBuffer loc0 = new StringBuffer ( ) ; int loc1 = 0 ; for ( ; ( loc1 < iLen ) && ( iType [ loc1 ] == 0 ) ; loc1 ++ ) { loc0 . append ( cLike [ loc1 ] ) ; } if ( loc1 == 0 ) { return null ; } return loc0 . toString ( ) ; }`

### sentBLEU=0.1
**pred:** `void function ( ) { }`

**ref:**  `BIEnumeration function ( Element arg0 , BindInfo arg1 ) { return new BIEnumeration ( arg0 , new CEnumLeafInfo ( arg1 . model , null , new CClassInfoParent . Package ( arg1 . getTargetPackage ( ) ) , DOMUtil . getAttribute ( arg0 , "srini_string" ) , CBuiltinLeafInfo . STRING , buildMemberList ( arg1`

### sentBLEU=0.2
**pred:** `FileTransfer function ( ) { return fileTransfer ; }`

**ref:**  `void function ( ) { try { incomingFileTransfer . close ( ) ; fileTransferOpSet . fireFileTransferRequestRejected ( new FileTransferRequestEvent ( fileTransferOpSet , this , date ) ) ; } catch ( IllegalStateException loc0 ) { if ( logger . isDebugEnabled ( ) ) logger . debug ( "srini_string" , loc0 )`

### sentBLEU=0.2
**pred:** `void function ( OrientationListener arg0 ) { mOrientationListener = arg0 ; }`

**ref:**  `void function ( ) { if ( mSensor == null ) { Log . w ( TAG , "srini_string" ) ; return ; } if ( mEnabled == false ) { if ( localLOGV ) Log . d ( TAG , "srini_string" ) ; mSensorManager . registerListener ( mSensorEventListener , mSensor , mRate ) ; mEnabled = true ; } }`

### sentBLEU=0.2
**pred:** `Path function ( JobConf arg0, Path arg1 ) { return arg0. get ( arg1 ) ; }`

**ref:**  `void function ( Collection < Operator < ? >> arg0 , Operator < ? > arg1 , Class < ? > arg2 ) { Preconditions . checkArgument ( arg2 != null , "srini_string" ) ; if ( arg1 == null ) { return ; } if ( arg2 . equals ( arg1 . getClass ( ) ) ) { arg0 . add ( arg1 ) ; } for ( Operator < ? > loc0 : arg1 . `

### sentBLEU=0.2
**pred:** `Validator function ( ) { return validator ; }`

**ref:**  `CertPathValidator function ( String arg0 , String arg1 ) { if ( arg1 == null ) throw new IllegalArgumentException ( "srini_string" ) ; Provider loc0 = Security . getProvider ( arg1 ) ; if ( loc0 == null ) throw new NoSuchProviderException ( arg1 ) ; return getInstance ( arg0 , loc0 ) ; }`

### sentBLEU=0.3
**pred:** `void function ( long arg0 ) { m_start = arg0 ; }`

**ref:**  `void function ( DRConsumerDrIdTracker arg0 ) { final long loc0 = Math . max ( arg0 . getSafePointDrId ( ) , getSafePointDrId ( ) ) ; m_map . addAll ( arg0 . m_map ) ; truncate ( loc0 ) ; m_lastSpUniqueId = Math . max ( m_lastSpUniqueId , arg0 . m_lastSpUniqueId ) ; m_lastMpUniqueId = Math . max ( m_`

### sentBLEU=0.3
**pred:** `Throwable function ( ) { return throwable ; }`

**ref:**  `Throwable function ( Throwable arg0 ) { Throwable loc0 = arg0 . getCause ( ) ; int loc1 = 0 ; while ( loc0 != null && ++ loc1 < 1024 ) { arg0 = loc0 ; loc0 = arg0 . getCause ( ) ; } return arg0 ; }`

### sentBLEU=0.3
**pred:** `String function ( ) { return "srini_string" ; }`

**ref:**  `void function ( String arg0 , String arg1 ) { try { FileWriter loc0 = new FileWriter ( arg0 ) ; loc0 . loc0 ( arg1 . toCharArray ( ) ) ; loc0 . close ( ) ; } catch ( IOException loc0 ) { loc0 . printStackTrace ( ) ; } }`
