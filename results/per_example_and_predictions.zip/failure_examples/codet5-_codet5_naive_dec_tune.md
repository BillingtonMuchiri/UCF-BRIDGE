# worst 15 of 1000 test examples by sentence BLEU -- codet5->codet5 | naive | dec_tune

### sentBLEU=0.0
**pred:** `void function ( ) { }`

**ref:**  `void function ( Run < ? , ? > arg0 , SCM arg1 , TaskListener arg2 , ChangeLogSet < ? > arg3 ) { if ( arg0 instanceof AbstractBuild && arg2 instanceof BuildListener && Util . isOverridden ( SCMListener . class , getClass ( ) , "srini_string" , AbstractBuild . class , BuildListener . class , ChangeLog`

### sentBLEU=0.0
**pred:** `void function ( ) { }`

**ref:**  `void function ( Path arg0 , TransitionList arg1 ) { if ( isLooping ) return ; if ( arg0 . continuousTime ( ) ) return ; if ( ! arg1 . isDeterministic ( ) ) return ; if ( arg0 . getPreviousState ( ) . equals ( arg0 . getCurrentState ( ) ) ) { isLooping = true ; loopStart = arg0 . size ( ) - 1 ; loopE`

### sentBLEU=0.0
**pred:** `void function ( ) { }`

**ref:**  `String function ( ) { StringBuffer loc0 = new StringBuffer ( ) ; int loc1 = 0 ; for ( ; ( loc1 < iLen ) && ( iType [ loc1 ] == 0 ) ; loc1 ++ ) { loc0 . append ( cLike [ loc1 ] ) ; } if ( loc1 == 0 ) { return null ; } return loc0 . toString ( ) ; }`

### sentBLEU=0.1
**pred:** `String function ( ) { return array + "srini_string" ; }`

**ref:**  `String function ( ) { int loc0 = array . length - 1 ; if ( loc0 == - 1 ) return "srini_string" ; StringBuilder loc1 = new StringBuilder ( ) ; loc1 . append ( '[' ) ; for ( int loc2 = 0 ; ; loc2 ++ ) { loc1 . append ( array [ loc2 ] ) ; if ( loc2 == loc0 ) return loc1 . append ( ']' ) . toString ( ) `

### sentBLEU=0.1
**pred:** `String function ( ) { return randomLeafFieldName ; }`

**ref:**  `String function ( Random arg0 ) { int loc0 = RandomInts . randomIntBetween ( arg0 , 1 , 5 ) ; String loc1 = "srini_string" ; for ( int loc2 = 0 ; loc2 < loc0 ; loc2 ++ ) { if ( loc2 > 0 ) { loc1 += "srini_string" ; } loc1 += randomString ( arg0 ) ; } return loc1 ; }`

### sentBLEU=0.1
**pred:** `double function ( ) { return this . totalScores [ 0 ] ; }`

**ref:**  `double function ( X arg0 ) { int loc0 = ids . get ( arg0 ) ; double loc1 = 0.0 ; double loc2 = 0.0 ; for ( int loc3 = 0 ; loc3 < size ; ++ loc3 ) { double loc4 = averageScoreFor ( loc3 ) ; loc1 += loc4 * scores [ loc0 ] [ loc3 ] ; loc2 += loc4 * games [ loc0 ] [ loc3 ] ; } return loc2 == 0.0 ? 0.0 :`

### sentBLEU=0.1
**pred:** `void function ( XSystemDependentWindowPeer arg0 ) { }`

**ref:**  `java . lang . Object function ( byte [ ] arg0 , short arg1 ) { Object loc0 = null ; if ( arg1 == maView . maSystem ) loc0 = ( Object ) maView . maHandle ; return loc0 ; }`

### sentBLEU=0.1
**pred:** `String function ( ) { return "srini_string" ; }`

**ref:**  `String function ( String [ ] arg0 ) { String loc0 = "srini_string" ; for ( int loc1 = 0 ; loc1 < arg0 . length ; loc1 ++ ) { for ( int loc2 = 0 ; loc2 < arg0 [ loc1 ] . length ( ) ; loc2 ++ ) { loc0 += "srini_string" ; } loc0 += "srini_string" ; } return loc0 ; }`

### sentBLEU=0.1
**pred:** `void function ( ActionEvent arg0 ) { }`

**ref:**  `void function ( ) { if ( isInputValid ( ) ) { String loc0 = mtg . generateText ( Integer . parseInt ( numWordsField . getText ( ) ) ) ; setResult ( loc0 ) ; } else { mainApp . showInputErrorDialog ( "srini_string" ) ; } }`

### sentBLEU=0.2
**pred:** `PollingResult function ( ) { return executePollingSappCommands ( ) ; }`

**ref:**  `void function ( String arg0 , int arg1 , int arg2 , int arg3 ) { synchronized ( this ) { SappCommand loc0 = new Sapp7DCommand ( arg2 , arg3 ) ; loc0 . run ( arg0 , arg1 ) ; if ( ! loc0 . isResponseOk ( ) ) { throw new SappException ( "srini_string" ) ; } } }`

### sentBLEU=0.2
**pred:** `Throwable function ( ) { return null ; }`

**ref:**  `Throwable function ( Throwable arg0 ) { Throwable loc0 = arg0 . getCause ( ) ; int loc1 = 0 ; while ( loc0 != null && ++ loc1 < 1024 ) { arg0 = loc0 ; loc0 = arg0 . getCause ( ) ; } return arg0 ; }`

### sentBLEU=0.3
**pred:** `CEnumDeclaration function ( ) { return new CEnumDeclaration ( name ) ; }`

**ref:**  `BIEnumeration function ( Element arg0 , BindInfo arg1 ) { return new BIEnumeration ( arg0 , new CEnumLeafInfo ( arg1 . model , null , new CClassInfoParent . Package ( arg1 . getTargetPackage ( ) ) , DOMUtil . getAttribute ( arg0 , "srini_string" ) , CBuiltinLeafInfo . STRING , buildMemberList ( arg1`

### sentBLEU=0.3
**pred:** `Prop function ( ) { return prop ; }`

**ref:**  `Prop function ( String arg0 , String arg1 ) { Prop loc0 = map . get ( arg0 ) ; if ( loc0 == null ) { loc0 = new Prop ( arg0 , arg1 ) ; map . put ( arg0 , loc0 ) ; if ( PropKit . prop == null ) PropKit . prop = loc0 ; } return loc0 ; }`

### sentBLEU=0.3
**pred:** `String function ( ) { return "srini_string" ; }`

**ref:**  `void function ( String arg0 , String arg1 ) { try { FileWriter loc0 = new FileWriter ( arg0 ) ; loc0 . loc0 ( arg1 . toCharArray ( ) ) ; loc0 . close ( ) ; } catch ( IOException loc0 ) { loc0 . printStackTrace ( ) ; } }`

### sentBLEU=0.3
**pred:** `Enum function ( ) { return this . m_Line ; }`

**ref:**  `T function ( String arg0 , Class < T > arg1 ) { String loc0 = getParameter ( arg0 ) ; if ( loc0 == null || "srini_string" . equals ( loc0 ) ) return null ; return Enum . valueOf ( arg1 , loc0 ) ; }`
