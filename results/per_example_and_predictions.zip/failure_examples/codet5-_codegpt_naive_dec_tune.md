# worst 15 of 1000 test examples by sentence BLEU -- codet5->codegpt | naive | dec_tune

### sentBLEU=0.0
**pred:** `void function ( ) { }`

**ref:**  `void function ( FacesContext arg0 , UIComponent arg1 ) { ArrayList loc0 = ( ArrayList ) arg0 . getAttributes ( ) . get ( FormEndRendering . class . getName ( ) ) ; if ( loc0 != null ) { Iterator loc1 = loc0 . iterator ( ) ; while ( loc1 . hasNext ( ) ) { FormEndRenderer loc2 = ( FormEndRenderer ) lo`

### sentBLEU=0.0
**pred:** `void function ( ) { }`

**ref:**  `String function ( ) { StringBuffer loc0 = new StringBuffer ( ) ; int loc1 = 0 ; for ( ; ( loc1 < iLen ) && ( iType [ loc1 ] == 0 ) ; loc1 ++ ) { loc0 . append ( cLike [ loc1 ] ) ; } if ( loc1 == 0 ) { return null ; } return loc0 . toString ( ) ; }`

### sentBLEU=0.0
**pred:** `void function ( ) { }`

**ref:**  `void function ( ) { if ( close ) return ; try { if ( p_stmt != null ) { p_stmt . close ( ) ; } } finally { if ( m_conn != null ) { try { m_conn . close ( ) ; } catch ( Exception loc0 ) { } } m_conn = null ; close = true ; } }`

### sentBLEU=0.0
**pred:** `int function ( ) { return this . length ; }`

**ref:**  `String function ( ) { int loc0 = array . length - 1 ; if ( loc0 == - 1 ) return "srini_string" ; StringBuilder loc1 = new StringBuilder ( ) ; loc1 . append ( '[' ) ; for ( int loc2 = 0 ; ; loc2 ++ ) { loc1 . append ( array [ loc2 ] ) ; if ( loc2 == loc0 ) return loc1 . append ( ']' ) . toString ( ) `

### sentBLEU=0.0
**pred:** `void function ( ) { }`

**ref:**  `void function ( ) { EventQueue . invokeLater ( new Runnable ( ) { public void run ( ) { try { Recommend loc0 = new Recommend ( ) ; loc0 . frame . setVisible ( true ) ; } catch ( Exception loc0 ) { loc0 . printStackTrace ( ) ; } } } ) ; }`

### sentBLEU=0.0
**pred:** `void function ( ) { }`

**ref:**  `Entry function ( ISelection arg0 ) { IStructuredSelection loc0 = ( IStructuredSelection ) arg0 ; Object loc1 = loc0 . getFirstElement ( ) ; if ( loc1 == null ) return null ; return ( ( EntryEditPart ) loc1 ) . resolveSemanticElement ( ) ; }`

### sentBLEU=0.0
**pred:** `void function ( ) { }`

**ref:**  `void function ( ) { String loc0 = readResource ( "srini_string" ) ; String loc1 = readResource ( "srini_string" ) ; HtmlCompressor loc2 = new HtmlCompressor ( ) ; loc2 . setRemoveJavaScriptProtocol ( true ) ; assertEquals ( loc1 , loc2 . compress ( loc0 ) ) ; }`

### sentBLEU=0.0
**pred:** `boolean function ( ) { return false ; }`

**ref:**  `boolean function ( State arg0 ) { switch ( arg0 ) { case r1_A : return stateVector [ 0 ] == State . r1_A ; case r1_B : return stateVector [ 0 ] == State . r1_B ; case r2_C : return stateVector [ 1 ] == State . r2_C ; case r2_D : return stateVector [ 1 ] == State . r2_D ; default : return false ; } }`

### sentBLEU=0.1
**pred:** `void function ( ) { }`

**ref:**  `void function ( ) { System . out . println ( "srini_string" ) ; DummySampler loc0 = new DummySampler ( ) ; String loc1 = "srini_string" ; String loc2 = loc0 . getResponseData ( ) ; Assert . assertEquals ( loc1 , loc2 ) ; }`

### sentBLEU=0.1
**pred:** `void function ( ) { }`

**ref:**  `void function ( ) { if ( isInputValid ( ) ) { String loc0 = mtg . generateText ( Integer . parseInt ( numWordsField . getText ( ) ) ) ; setResult ( loc0 ) ; } else { mainApp . showInputErrorDialog ( "srini_string" ) ; } }`

### sentBLEU=0.1
**pred:** `int function ( ) { return m_nWidth ; }`

**ref:**  `String function ( ) { double loc0 = getRate ( ) ; if ( loc0 == Double . MAX_VALUE ) { return "srini_string" ; } String loc1 = "srini_string" ; if ( loc0 < 1.0 ) { loc0 *= 60.0 ; loc1 = "srini_string" ; } if ( loc0 < 1.0 ) { loc0 *= 60.0 ; loc1 = "srini_string" ; } return rateFormatter . format ( loc`

### sentBLEU=0.1
**pred:** `String function ( ) { return "srini_string" ; }`

**ref:**  `BIEnumeration function ( Element arg0 , BindInfo arg1 ) { return new BIEnumeration ( arg0 , new CEnumLeafInfo ( arg1 . model , null , new CClassInfoParent . Package ( arg1 . getTargetPackage ( ) ) , DOMUtil . getAttribute ( arg0 , "srini_string" ) , CBuiltinLeafInfo . STRING , buildMemberList ( arg1`

### sentBLEU=0.1
**pred:** `int function ( ) { return this . maxDepth ; }`

**ref:**  `double function ( X arg0 ) { int loc0 = ids . get ( arg0 ) ; double loc1 = 0.0 ; double loc2 = 0.0 ; for ( int loc3 = 0 ; loc3 < size ; ++ loc3 ) { double loc4 = averageScoreFor ( loc3 ) ; loc1 += loc4 * scores [ loc0 ] [ loc3 ] ; loc2 += loc4 * games [ loc0 ] [ loc3 ] ; } return loc2 == 0.0 ? 0.0 :`

### sentBLEU=0.1
**pred:** `String function ( ) { return this . url ; }`

**ref:**  `boolean function ( UserEdit arg0 , String arg1 ) { if ( m_requirelocalaccount ) return false ; String loc0 = arg1 . toLowerCase ( ) . trim ( ) ; if ( ! loc0 . endsWith ( m_domain ) ) return false ; String loc1 [ ] = StringUtil . splitFirst ( loc0 , "srini_string" ) ; arg0 . setEid ( loc1 [ 0 ] ) ; r`

### sentBLEU=0.1
**pred:** `String function ( ) { return this . name ; }`

**ref:**  `String function ( ) { final VirtualFile loc0 = _parent . get ( ) ; if ( loc0 == null || loc0 . getParent ( ) == null ) return "srini_string" ; else { final String loc1 = loc0 . getUnixPathWithoutContainer ( ) ; if ( loc1 . isEmpty ( ) ) return getName ( ) ; else return loc1 + VIRTUAL_FILE_SEPARATOR `
