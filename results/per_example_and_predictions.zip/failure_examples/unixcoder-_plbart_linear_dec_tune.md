# worst 15 of 1000 test examples by sentence BLEU -- unixcoder->plbart | linear | dec_tune

### sentBLEU=0.0
**pred:** `void function ( ) { }`

**ref:**  `void function ( Path arg0 , TransitionList arg1 ) { if ( isLooping ) return ; if ( arg0 . continuousTime ( ) ) return ; if ( ! arg1 . isDeterministic ( ) ) return ; if ( arg0 . getPreviousState ( ) . equals ( arg0 . getCurrentState ( ) ) ) { isLooping = true ; loopStart = arg0 . size ( ) - 1 ; loopE`

### sentBLEU=0.0
**pred:** `void function ( ) { }`

**ref:**  `BIEnumeration function ( Element arg0 , BindInfo arg1 ) { return new BIEnumeration ( arg0 , new CEnumLeafInfo ( arg1 . model , null , new CClassInfoParent . Package ( arg1 . getTargetPackage ( ) ) , DOMUtil . getAttribute ( arg0 , "srini_string" ) , CBuiltinLeafInfo . STRING , buildMemberList ( arg1`

### sentBLEU=0.0
**pred:** `double function ( ) { return this. score ; }`

**ref:**  `double function ( X arg0 ) { int loc0 = ids . get ( arg0 ) ; double loc1 = 0.0 ; double loc2 = 0.0 ; for ( int loc3 = 0 ; loc3 < size ; ++ loc3 ) { double loc4 = averageScoreFor ( loc3 ) ; loc1 += loc4 * scores [ loc0 ] [ loc3 ] ; loc2 += loc4 * games [ loc0 ] [ loc3 ] ; } return loc2 == 0.0 ? 0.0 :`

### sentBLEU=0.0
**pred:** `void function ( ) { }`

**ref:**  `void function ( String arg0 , int arg1 , int arg2 , int arg3 ) { synchronized ( this ) { SappCommand loc0 = new Sapp7DCommand ( arg2 , arg3 ) ; loc0 . run ( arg0 , arg1 ) ; if ( ! loc0 . isResponseOk ( ) ) { throw new SappException ( "srini_string" ) ; } } }`

### sentBLEU=0.0
**pred:** `String function ( ) { return this. key ; }`

**ref:**  `String function ( ) { int loc0 = array . length - 1 ; if ( loc0 == - 1 ) return "srini_string" ; StringBuilder loc1 = new StringBuilder ( ) ; loc1 . append ( '[' ) ; for ( int loc2 = 0 ; ; loc2 ++ ) { loc1 . append ( array [ loc2 ] ) ; if ( loc2 == loc0 ) return loc1 . append ( ']' ) . toString ( ) `

### sentBLEU=0.0
**pred:** `void function ( ) { }`

**ref:**  `void function ( ) { EventQueue . invokeLater ( new Runnable ( ) { public void run ( ) { try { Recommend loc0 = new Recommend ( ) ; loc0 . frame . setVisible ( true ) ; } catch ( Exception loc0 ) { loc0 . printStackTrace ( ) ; } } } ) ; }`

### sentBLEU=0.0
**pred:** `String function ( ) { return lang ; }`

**ref:**  `void function ( String arg0 , String arg1 , boolean arg2 ) { arg1 = normalize ( arg1 ) ; String loc0 = loc0 ( arg0 , arg1 ) ; if ( arg2 ) { prefs . getNode ( NODE_ID ) . putBoolean ( loc0 , true ) ; } else { prefs . getNode ( NODE_ID ) . remove ( loc0 ) ; } }`

### sentBLEU=0.0
**pred:** `void function ( HttpServletRequest arg0, HttpServletResponse arg1 ) { }`

**ref:**  `void function ( FacesContext arg0 , UIComponent arg1 ) { ArrayList loc0 = ( ArrayList ) arg0 . getAttributes ( ) . get ( FormEndRendering . class . getName ( ) ) ; if ( loc0 != null ) { Iterator loc1 = loc0 . iterator ( ) ; while ( loc1 . hasNext ( ) ) { FormEndRenderer loc2 = ( FormEndRenderer ) lo`

### sentBLEU=0.1
**pred:** `Provider function ( ) { return provider ; }`

**ref:**  `CertPathValidator function ( String arg0 , String arg1 ) { if ( arg1 == null ) throw new IllegalArgumentException ( "srini_string" ) ; Provider loc0 = Security . getProvider ( arg1 ) ; if ( loc0 == null ) throw new NoSuchProviderException ( arg1 ) ; return getInstance ( arg0 , loc0 ) ; }`

### sentBLEU=0.1
**pred:** `String function ( ) { return "srini_string" ; }`

**ref:**  `String function ( ) { double loc0 = getRate ( ) ; if ( loc0 == Double . MAX_VALUE ) { return "srini_string" ; } String loc1 = "srini_string" ; if ( loc0 < 1.0 ) { loc0 *= 60.0 ; loc1 = "srini_string" ; } if ( loc0 < 1.0 ) { loc0 *= 60.0 ; loc1 = "srini_string" ; } return rateFormatter . format ( loc`

### sentBLEU=0.1
**pred:** `String function ( ) { return m_virtualPath ; }`

**ref:**  `String function ( ) { final VirtualFile loc0 = _parent . get ( ) ; if ( loc0 == null || loc0 . getParent ( ) == null ) return "srini_string" ; else { final String loc1 = loc0 . getUnixPathWithoutContainer ( ) ; if ( loc1 . isEmpty ( ) ) return getName ( ) ; else return loc1 + VIRTUAL_FILE_SEPARATOR `

### sentBLEU=0.1
**pred:** `boolean function ( View arg0 ) { return false ; }`

**ref:**  `void function ( final ViewGroup arg0 , final boolean arg1 ) { for ( int loc0 = 0 ; loc0 < arg0 . getChildCount ( ) ; loc0 ++ ) { final View loc1 = arg0 . getChildAt ( loc0 ) ; if ( loc1 == null ) continue ; loc1 . setSelected ( arg1 ) ; if ( loc1 instanceof ViewGroup ) { setSelectedForAllChildrenRec`

### sentBLEU=0.1
**pred:** `List < String > function ( ) { return projects ; }`

**ref:**  `void function ( String arg0 , int arg1 , int arg2 ) { ProjectComboBO loc0 = new ProjectComboBO ( ) ; this . mtxProjectList = loc0 . getProjectComboList ( arg0 , arg1 , arg2 , LIST_ALL_PROJECT ) ; if ( this . strProjectID . length ( ) < 2 ) { this . strProjectID = this . mtxProjectList . getCell ( 0 `

### sentBLEU=0.2
**pred:** `void function ( SelectionKey arg0 ) { }`

**ref:**  `Entry function ( ISelection arg0 ) { IStructuredSelection loc0 = ( IStructuredSelection ) arg0 ; Object loc1 = loc0 . getFirstElement ( ) ; if ( loc1 == null ) return null ; return ( ( EntryEditPart ) loc1 ) . resolveSemanticElement ( ) ; }`

### sentBLEU=0.3
**pred:** `void function ( ) { }`

**ref:**  `boolean function ( AlignmentInColumnsConfig arg0 , ASTNode arg1 , NodeProcessor arg2 ) { return findPreviousNode ( arg0 , arg1 , arg1 . getElementType ( ) , false , true , arg2 ) ; }`
