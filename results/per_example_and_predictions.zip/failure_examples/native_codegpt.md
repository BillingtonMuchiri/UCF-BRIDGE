# worst 15 of 1000 test examples by sentence BLEU -- native:codegpt

### sentBLEU=0.0
**pred:** `void function ( ) { }`

**ref:**  `String function ( ) { StringBuffer loc0 = new StringBuffer ( ) ; int loc1 = 0 ; for ( ; ( loc1 < iLen ) && ( iType [ loc1 ] == 0 ) ; loc1 ++ ) { loc0 . append ( cLike [ loc1 ] ) ; } if ( loc1 == 0 ) { return null ; } return loc0 . toString ( ) ; }`

### sentBLEU=0.0
**pred:** `double function ( ) { return ci0Max ; }`

**ref:**  `int function ( CDouble arg0 ) { if ( Thread . interrupted ( ) ) { throw new InterruptedException ( ) ; } CDouble loc0 = CDouble . ZERO ; for ( int loc1 = 0 ; loc1 < maxIter ; loc1 ++ ) { loc0 = loc0 . squared ( ) . add ( arg0 ) ; if ( loc0 . abs2 ( ) > 10.0 ) return loc1 ; } return - 1 ; }`

### sentBLEU=0.0
**pred:** `double function ( ) { return totalScores [ 0 ] ; }`

**ref:**  `double function ( X arg0 ) { int loc0 = ids . get ( arg0 ) ; double loc1 = 0.0 ; double loc2 = 0.0 ; for ( int loc3 = 0 ; loc3 < size ; ++ loc3 ) { double loc4 = averageScoreFor ( loc3 ) ; loc1 += loc4 * scores [ loc0 ] [ loc3 ] ; loc2 += loc4 * games [ loc0 ] [ loc3 ] ; } return loc2 == 0.0 ? 0.0 :`

### sentBLEU=0.0
**pred:** `void function ( ) { }`

**ref:**  `void function ( ) { for ( int loc0 = 0 ; loc0 < parts . size ( ) ; loc0 ++ ) { IFormPart loc1 = parts . get ( loc0 ) ; loc1 . dispose ( ) ; } if ( ownsToolkit ) { toolkit . dispose ( ) ; } }`

### sentBLEU=0.1
**pred:** `void function ( ) { }`

**ref:**  `java . lang . Object function ( byte [ ] arg0 , short arg1 ) { Object loc0 = null ; if ( arg1 == maView . maSystem ) loc0 = ( Object ) maView . maHandle ; return loc0 ; }`

### sentBLEU=0.1
**pred:** `File function ( ) { return mBaseName ; }`

**ref:**  `void function ( FileOutputStream arg0 ) { if ( arg0 != null ) { sync ( arg0 ) ; try { arg0 . close ( ) ; mBackupName . delete ( ) ; } catch ( IOException loc0 ) { Log . w ( "srini_string" , "srini_string" , loc0 ) ; } } }`

### sentBLEU=0.1
**pred:** `FastVector function ( ) { return children ; }`

**ref:**  `Object function ( ) { PredictionNode loc0 = new PredictionNode ( value ) ; for ( Enumeration loc1 = children . elements ( ) ; loc1 . hasMoreElements ( ) ; ) loc0 . children . addElement ( ( Splitter ) ( ( Splitter ) loc1 . nextElement ( ) ) . loc0 ( ) ) ; return loc0 ; }`

### sentBLEU=0.1
**pred:** `void function ( final FacesContext arg0 , final UIComponent arg1 ) { }`

**ref:**  `void function ( FacesContext arg0 , UIComponent arg1 ) { ArrayList loc0 = ( ArrayList ) arg0 . getAttributes ( ) . get ( FormEndRendering . class . getName ( ) ) ; if ( loc0 != null ) { Iterator loc1 = loc0 . iterator ( ) ; while ( loc1 . hasNext ( ) ) { FormEndRenderer loc2 = ( FormEndRenderer ) lo`

### sentBLEU=0.2
**pred:** `String function ( ) { return mBuffer . toString ( ) ; }`

**ref:**  `String function ( char arg0 ) { if ( isEmpty ( ) ) { return "srini_string" ; } int loc0 = mBuffer . substring ( mPos ) . indexOf ( arg0 ) ; if ( loc0 == - 1 ) { return rest ( ) ; } else { loc0 += mPos ; String loc1 = mBuffer . substring ( mPos , loc0 ) ; mPos = loc0 + 1 ; return loc1 ; } }`

### sentBLEU=0.2
**pred:** `int function ( ) { return executeSapp7CCommand ; }`

**ref:**  `void function ( String arg0 , int arg1 , int arg2 , int arg3 ) { synchronized ( this ) { SappCommand loc0 = new Sapp7DCommand ( arg2 , arg3 ) ; loc0 . run ( arg0 , arg1 ) ; if ( ! loc0 . isResponseOk ( ) ) { throw new SappException ( "srini_string" ) ; } } }`

### sentBLEU=0.2
**pred:** `boolean function ( ) { return mEventsAdded < mEventsRemoved ; }`

**ref:**  `SchedulableEvent function ( long arg0 ) { SchedulableEvent loc0 = null ; synchronized ( lock ) { if ( ! mEventBuffer . isEmpty ( ) ) { long loc1 = mEventBuffer . firstKey ( ) ; if ( loc1 <= arg0 ) { loc0 = removeNextEventLocked ( loc1 ) ; } } } return loc0 ; }`

### sentBLEU=0.2
**pred:** `String function ( ) { return MAPPING_FILE_NAME ; }`

**ref:**  `void function ( Element arg0 , SpringPersistenceUnitInfo arg1 ) { List < Element > loc0 = DomUtils . getChildElementsByTagName ( arg0 , MAPPING_FILE_NAME ) ; for ( Element loc1 : loc0 ) { String loc2 = DomUtils . getTextValue ( loc1 ) . trim ( ) ; if ( StringUtils . hasText ( loc2 ) ) { arg1 . addMa`

### sentBLEU=0.3
**pred:** `void function ( ) { }`

**ref:**  `void function ( String arg0 ) { if ( myHost != null ) { myHost . showFeedback ( arg0 ) ; } else { System . out . println ( arg0 ) ; } }`

### sentBLEU=0.3
**pred:** `String function ( ) { return "srini_string" ; }`

**ref:**  `void function ( String arg0 , String arg1 ) { try { FileWriter loc0 = new FileWriter ( arg0 ) ; loc0 . loc0 ( arg1 . toCharArray ( ) ) ; loc0 . close ( ) ; } catch ( IOException loc0 ) { loc0 . printStackTrace ( ) ; } }`

### sentBLEU=0.4
**pred:** `BreadCrumbPanel function ( ) { return getPanel ( ) ; }`

**ref:**  `BreadCrumbPanel function ( IBreadCrumbModel arg0 ) { int loc0 = arg0 . allBreadCrumbParticipants ( ) . size ( ) ; if ( loc0 > 0 ) { arg0 . setActive ( ( IBreadCrumbParticipant ) arg0 . allBreadCrumbParticipants ( ) . get ( 0 ) ) ; } return ( BreadCrumbPanel ) arg0 . getActive ( ) . getComponent ( ) `
