# worst 15 of 1000 test examples by sentence BLEU -- unixcoder->plbart | naive | dec_tune

### sentBLEU=0.0
**pred:** `void function ( ) { }`

**ref:**  `boolean function ( State arg0 ) { switch ( arg0 ) { case r1_A : return stateVector [ 0 ] == State . r1_A ; case r1_B : return stateVector [ 0 ] == State . r1_B ; case r2_C : return stateVector [ 1 ] == State . r2_C ; case r2_D : return stateVector [ 1 ] == State . r2_D ; default : return false ; } }`

### sentBLEU=0.0
**pred:** `String function ( ) { return this. length ; }`

**ref:**  `String function ( ) { double loc0 = getRate ( ) ; if ( loc0 == Double . MAX_VALUE ) { return "srini_string" ; } String loc1 = "srini_string" ; if ( loc0 < 1.0 ) { loc0 *= 60.0 ; loc1 = "srini_string" ; } if ( loc0 < 1.0 ) { loc0 *= 60.0 ; loc1 = "srini_string" ; } return rateFormatter . format ( loc`

### sentBLEU=0.0
**pred:** `String function ( ) { return m_string" ; }`

**ref:**  `int function ( Conversation arg0 ) { int loc0 = Arrays . binarySearch ( typeList , getType ( ) ) ; int loc1 = Arrays . binarySearch ( typeList , arg0 . getType ( ) ) ; if ( loc0 == loc1 ) { return name . compareToIgnoreCase ( arg0 . name ) ; } return Integer . valueOf ( loc1 ) . compareTo ( Integer `

### sentBLEU=0.1
**pred:** `double function ( ) { return this. size ( ) ; }`

**ref:**  `double function ( X arg0 ) { int loc0 = ids . get ( arg0 ) ; double loc1 = 0.0 ; double loc2 = 0.0 ; for ( int loc3 = 0 ; loc3 < size ; ++ loc3 ) { double loc4 = averageScoreFor ( loc3 ) ; loc1 += loc4 * scores [ loc0 ] [ loc3 ] ; loc2 += loc4 * games [ loc0 ] [ loc3 ] ; } return loc2 == 0.0 ? 0.0 :`

### sentBLEU=0.1
**pred:** `boolean function ( ) { return null ; }`

**ref:**  `User function ( String arg0 , String arg1 ) { if ( arg0 == null ) { arg0 = "srini_string" ; } if ( arg1 == null ) { arg1 = "srini_string" ; } User loc0 = get ( arg0 ) ; loc0 . checkPassword ( arg1 ) ; return loc0 ; }`

### sentBLEU=0.1
**pred:** `void function ( double arg0 ) { this. size ( arg0 ) ; }`

**ref:**  `Fraction [ ] [ ] function ( int arg0 , int arg1 , Fraction arg2 ) { Fraction [ ] [ ] loc0 = new Fraction [ arg0 ] [ arg1 ] ; for ( int loc1 = 0 ; loc1 < arg0 ; loc1 ++ ) { for ( int loc2 = 0 ; loc2 < arg1 ; loc2 ++ ) { loc0 [ loc1 ] [ loc2 ] = arg2 ; } } return loc0 ; }`

### sentBLEU=0.1
**pred:** `String function ( ) { return null ; }`

**ref:**  `void function ( String arg0 , String arg1 , boolean arg2 ) { arg1 = normalize ( arg1 ) ; String loc0 = loc0 ( arg0 , arg1 ) ; if ( arg2 ) { prefs . getNode ( NODE_ID ) . putBoolean ( loc0 , true ) ; } else { prefs . getNode ( NODE_ID ) . remove ( loc0 ) ; } }`

### sentBLEU=0.1
**pred:** `long function ( ) { return new Illegalitive ( ) ; }`

**ref:**  `String function ( ) { int loc0 = array . length - 1 ; if ( loc0 == - 1 ) return "srini_string" ; StringBuilder loc1 = new StringBuilder ( ) ; loc1 . append ( '[' ) ; for ( int loc2 = 0 ; ; loc2 ++ ) { loc1 . append ( array [ loc2 ] ) ; if ( loc2 == loc0 ) return loc1 . append ( ']' ) . toString ( ) `

### sentBLEU=0.2
**pred:** `void function ( ) { }`

**ref:**  `BIEnumeration function ( Element arg0 , BindInfo arg1 ) { return new BIEnumeration ( arg0 , new CEnumLeafInfo ( arg1 . model , null , new CClassInfoParent . Package ( arg1 . getTargetPackage ( ) ) , DOMUtil . getAttribute ( arg0 , "srini_string" ) , CBuiltinLeafInfo . STRING , buildMemberList ( arg1`

### sentBLEU=0.2
**pred:** `JSONArray function ( JSONArray arg0 ) { return new JSONArray ( arg0 ) ; }`

**ref:**  `JSONArray function ( JSONArray arg0 , JSONTokener arg1 ) { if ( arg0 == null || arg0 . length ( ) == 0 ) { return null ; } JSONArray loc0 = new JSONArray ( ) ; for ( ; ; ) { JSONObject loc1 = rowToJSONObject ( arg0 , arg1 ) ; if ( loc1 == null ) { break ; } loc0 . put ( loc1 ) ; } if ( loc0 . length`

### sentBLEU=0.2
**pred:** `String function ( String arg0 ) { return arg0. toString ( arg0 ) ; }`

**ref:**  `Map < String , ? > function ( Properties arg0 , String arg1 ) { Map < String , Object > loc0 = new HashMap < String , Object > ( ) ; for ( String loc1 : arg0 . stringPropertyNames ( ) ) { if ( loc1 . startsWith ( arg1 ) ) { String loc2 = loc1 . substring ( arg1 . length ( ) ) ; loc0 . put ( loc2 , a`

### sentBLEU=0.2
**pred:** `boolean function ( ) { return new IllegalArgumentException ( ) ; }`

**ref:**  `List < T > function ( List < T > arg0 , String arg1 ) { notNull ( arg0 , arg1 ) ; for ( int loc0 = 0 ; loc0 < arg0 . size ( ) ; loc0 ++ ) { notNull ( arg0 . get ( loc0 ) , MessageFormat . format ( "srini_string" , arg1 , loc0 ) ) ; } return arg0 ; }`

### sentBLEU=0.2
**pred:** `String function ( ) { return new File ( ) ; }`

**ref:**  `void function ( Element arg0 , SpringPersistenceUnitInfo arg1 ) { List < Element > loc0 = DomUtils . getChildElementsByTagName ( arg0 , MAPPING_FILE_NAME ) ; for ( Element loc1 : loc0 ) { String loc2 = DomUtils . getTextValue ( loc1 ) . trim ( ) ; if ( StringUtils . hasText ( loc2 ) ) { arg1 . addMa`

### sentBLEU=0.2
**pred:** `void function ( String arg0 ) { this. add ( arg0 ) ; }`

**ref:**  `boolean function ( XMLStreamReader arg0 , String arg1 , String arg2 ) { if ( arg0 != null && arg1 != null && arg2 != null ) { if ( arg0 . getEventType ( ) == XMLStreamConstants . START_ELEMENT ) { String loc0 = arg0 . getAttributeValue ( null , arg1 ) ; return arg2 . equals ( loc0 ) ; } } return fal`

### sentBLEU=0.2
**pred:** `void function ( ) { if ( "srini_string" ) { } }`

**ref:**  `void function ( Run < ? , ? > arg0 , SCM arg1 , TaskListener arg2 , ChangeLogSet < ? > arg3 ) { if ( arg0 instanceof AbstractBuild && arg2 instanceof BuildListener && Util . isOverridden ( SCMListener . class , getClass ( ) , "srini_string" , AbstractBuild . class , BuildListener . class , ChangeLog`
