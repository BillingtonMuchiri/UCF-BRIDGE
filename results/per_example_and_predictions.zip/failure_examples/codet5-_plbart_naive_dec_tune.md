# worst 15 of 1000 test examples by sentence BLEU -- codet5->plbart | naive | dec_tune

### sentBLEU=0.0
**pred:** `void function ( ) { }`

**ref:**  `void function ( FacesContext arg0 , UIComponent arg1 ) { ArrayList loc0 = ( ArrayList ) arg0 . getAttributes ( ) . get ( FormEndRendering . class . getName ( ) ) ; if ( loc0 != null ) { Iterator loc1 = loc0 . iterator ( ) ; while ( loc1 . hasNext ( ) ) { FormEndRenderer loc2 = ( FormEndRenderer ) lo`

### sentBLEU=0.0
**pred:** `void function ( ) { }`

**ref:**  `void function ( ) { Subscriber < String > loc0 = new TestSubscriber < String > ( ) ; final AtomicLong loc1 = new AtomicLong ( ) ; loc0 . setProducer ( new Producer ( ) { @ Override public void request ( long arg0 ) { loc1 . set ( arg0 ) ; } } ) ; assertEquals ( Long . MAX_VALUE , loc1 . get ( ) ) ; `

### sentBLEU=0.0
**pred:** `void function ( ) { }`

**ref:**  `void function ( ) { StrokeMap loc0 = new StrokeMap ( ) ; loc0 . put ( "srini_string" , new BasicStroke ( 1.1f ) ) ; loc0 . put ( "srini_string" , new BasicStroke ( 2.2f ) ) ; StrokeMap loc1 = ( StrokeMap ) TestUtilities . serialised ( loc0 ) ; assertEquals ( loc0 , loc1 ) ; }`

### sentBLEU=0.0
**pred:** `int function ( ) { return m_n_a_b ; }`

**ref:**  `double function ( X arg0 ) { int loc0 = ids . get ( arg0 ) ; double loc1 = 0.0 ; double loc2 = 0.0 ; for ( int loc3 = 0 ; loc3 < size ; ++ loc3 ) { double loc4 = averageScoreFor ( loc3 ) ; loc1 += loc4 * scores [ loc0 ] [ loc3 ] ; loc2 += loc4 * games [ loc0 ] [ loc3 ] ; } return loc2 == 0.0 ? 0.0 :`

### sentBLEU=0.0
**pred:** `void function ( ) { }`

**ref:**  `void function ( ) { DialCap loc0 = new DialCap ( ) ; DialCap loc1 = new DialCap ( ) ; assertTrue ( loc0 . equals ( loc1 ) ) ; loc0 . setVisible ( false ) ; assertFalse ( loc0 . equals ( loc1 ) ) ; loc1 . setVisible ( false ) ; assertTrue ( loc0 . equals ( loc1 ) ) ; }`

### sentBLEU=0.0
**pred:** `void function ( ) { }`

**ref:**  `void function ( ) { EventQueue . invokeLater ( new Runnable ( ) { public void run ( ) { try { Recommend loc0 = new Recommend ( ) ; loc0 . frame . setVisible ( true ) ; } catch ( Exception loc0 ) { loc0 . printStackTrace ( ) ; } } } ) ; }`

### sentBLEU=0.0
**pred:** `int function ( ) { return this. total ; }`

**ref:**  `String function ( ) { double loc0 = getRate ( ) ; if ( loc0 == Double . MAX_VALUE ) { return "srini_string" ; } String loc1 = "srini_string" ; if ( loc0 < 1.0 ) { loc0 *= 60.0 ; loc1 = "srini_string" ; } if ( loc0 < 1.0 ) { loc0 *= 60.0 ; loc1 = "srini_string" ; } return rateFormatter . format ( loc`

### sentBLEU=0.0
**pred:** `void function ( ) { }`

**ref:**  `void function ( CompletableFuture < ? extends T > arg0 ) { arg0 . handle ( ( value , failure ) -> { if ( failure == null ) { success ( value ) ; } else { error ( failure ) ; } return null ; } ) ; }`

### sentBLEU=0.0
**pred:** `String function ( ) { return this. value ; }`

**ref:**  `String function ( ) { int loc0 = array . length - 1 ; if ( loc0 == - 1 ) return "srini_string" ; StringBuilder loc1 = new StringBuilder ( ) ; loc1 . append ( '[' ) ; for ( int loc2 = 0 ; ; loc2 ++ ) { loc1 . append ( array [ loc2 ] ) ; if ( loc2 == loc0 ) return loc1 . append ( ']' ) . toString ( ) `

### sentBLEU=0.0
**pred:** `void function ( ) { }`

**ref:**  `Entry function ( ISelection arg0 ) { IStructuredSelection loc0 = ( IStructuredSelection ) arg0 ; Object loc1 = loc0 . getFirstElement ( ) ; if ( loc1 == null ) return null ; return ( ( EntryEditPart ) loc1 ) . resolveSemanticElement ( ) ; }`

### sentBLEU=0.0
**pred:** `void function ( ) { }`

**ref:**  `void function ( CssErrorCode arg0 , CssReader arg1 , Object ... arg2 ) { CssScannerException loc0 = new CssScannerException ( arg0 , CssLocation . create ( arg1 ) , arg2 ) ; errors . add ( loc0 ) ; errorListener . error ( loc0 ) ; }`

### sentBLEU=0.0
**pred:** `void function ( ) { }`

**ref:**  `void function ( ) { fPresenter = getPresenterProvider ( ) . get ( ) ; fPresenter . install ( fSourceViewer , fPresentationReconciler ) ; if ( styledTextXtextAdapter != null ) { fReconciler = reconcilerProvider . get ( ) ; fReconciler . install ( styledTextXtextAdapter , fSourceViewer , fPresenter ) `

### sentBLEU=0.0
**pred:** `int function ( ) { return m_nThreads ; }`

**ref:**  `BitVector function ( int arg0 , int arg1 ) { m_ReadCoilsRequest . setReference ( arg0 ) ; m_ReadCoilsRequest . setBitCount ( arg1 ) ; m_Transaction . setRequest ( m_ReadCoilsRequest ) ; m_Transaction . execute ( ) ; BitVector loc0 = ( ( ReadCoilsResponse ) m_Transaction . getResponse ( ) ) . getCoil`

### sentBLEU=0.1
**pred:** `void function ( ) { }`

**ref:**  `void function ( ) { System . out . println ( "srini_string" ) ; DummySampler loc0 = new DummySampler ( ) ; String loc1 = "srini_string" ; String loc2 = loc0 . getResponseData ( ) ; Assert . assertEquals ( loc1 , loc2 ) ; }`

### sentBLEU=0.1
**pred:** `BeanFactory function ( ) { return factory ; }`

**ref:**  `CertPathValidator function ( String arg0 , String arg1 ) { if ( arg1 == null ) throw new IllegalArgumentException ( "srini_string" ) ; Provider loc0 = Security . getProvider ( arg1 ) ; if ( loc0 == null ) throw new NoSuchProviderException ( arg1 ) ; return getInstance ( arg0 , loc0 ) ; }`
