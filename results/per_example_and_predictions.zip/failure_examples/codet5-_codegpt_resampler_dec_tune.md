# worst 15 of 1000 test examples by sentence BLEU -- codet5->codegpt | resampler | dec_tune

### sentBLEU=0.0
**pred:** `double function ( ) { return this . totalCount ; }`

**ref:**  `double function ( X arg0 ) { int loc0 = ids . get ( arg0 ) ; double loc1 = 0.0 ; double loc2 = 0.0 ; for ( int loc3 = 0 ; loc3 < size ; ++ loc3 ) { double loc4 = averageScoreFor ( loc3 ) ; loc1 += loc4 * scores [ loc0 ] [ loc3 ] ; loc2 += loc4 * games [ loc0 ] [ loc3 ] ; } return loc2 == 0.0 ? 0.0 :`

### sentBLEU=0.0
**pred:** `String function ( ) { return this . value ; }`

**ref:**  `String function ( ) { int loc0 = array . length - 1 ; if ( loc0 == - 1 ) return "srini_string" ; StringBuilder loc1 = new StringBuilder ( ) ; loc1 . append ( '[' ) ; for ( int loc2 = 0 ; ; loc2 ++ ) { loc1 . append ( array [ loc2 ] ) ; if ( loc2 == loc0 ) return loc1 . append ( ']' ) . toString ( ) `

### sentBLEU=0.0
**pred:** `void function ( ) { }`

**ref:**  `void function ( ) { EventQueue . invokeLater ( new Runnable ( ) { public void run ( ) { try { Recommend loc0 = new Recommend ( ) ; loc0 . frame . setVisible ( true ) ; } catch ( Exception loc0 ) { loc0 . printStackTrace ( ) ; } } } ) ; }`

### sentBLEU=0.0
**pred:** `void function ( ) { }`

**ref:**  `void function ( ) { for ( int loc0 = 0 ; loc0 < parts . size ( ) ; loc0 ++ ) { IFormPart loc1 = parts . get ( loc0 ) ; loc1 . dispose ( ) ; } if ( ownsToolkit ) { toolkit . dispose ( ) ; } }`

### sentBLEU=0.0
**pred:** `void function ( ) { }`

**ref:**  `void function ( ) { fPresenter = getPresenterProvider ( ) . get ( ) ; fPresenter . install ( fSourceViewer , fPresentationReconciler ) ; if ( styledTextXtextAdapter != null ) { fReconciler = reconcilerProvider . get ( ) ; fReconciler . install ( styledTextXtextAdapter , fSourceViewer , fPresenter ) `

### sentBLEU=0.0
**pred:** `void function ( ) { }`

**ref:**  `BIEnumeration function ( Element arg0 , BindInfo arg1 ) { return new BIEnumeration ( arg0 , new CEnumLeafInfo ( arg1 . model , null , new CClassInfoParent . Package ( arg1 . getTargetPackage ( ) ) , DOMUtil . getAttribute ( arg0 , "srini_string" ) , CBuiltinLeafInfo . STRING , buildMemberList ( arg1`

### sentBLEU=0.1
**pred:** `void function ( ) { }`

**ref:**  `java . lang . Object function ( byte [ ] arg0 , short arg1 ) { Object loc0 = null ; if ( arg1 == maView . maSystem ) loc0 = ( Object ) maView . maHandle ; return loc0 ; }`

### sentBLEU=0.1
**pred:** `void function ( ) { }`

**ref:**  `void function ( ) { if ( isInputValid ( ) ) { String loc0 = mtg . generateText ( Integer . parseInt ( numWordsField . getText ( ) ) ) ; setResult ( loc0 ) ; } else { mainApp . showInputErrorDialog ( "srini_string" ) ; } }`

### sentBLEU=0.1
**pred:** `String function ( ) { return "srini_string" ; }`

**ref:**  `void function ( String arg0 ) { int loc0 = Integer . parseInt ( arg0 ) ; this . player = loc0 ; this . optionsView . setPlayerCount ( loc0 ) ; if ( loc0 != 0 ) { this . playerIsKi = new boolean [ loc0 - 1 ] ; } this . optionsView . setPlayerToggle ( loc0 ) ; }`

### sentBLEU=0.1
**pred:** `boolean function ( ) { return ! isClosed ; }`

**ref:**  `boolean function ( ) { row = parser . parseNext ( ) ; if ( row == null && blockCounter + 1 >= this . csvParserVo . getBlockDetailsList ( ) . size ( ) ) { close ( ) ; return false ; } if ( row == null ) { initialize ( ) ; row = parser . parseNext ( ) ; } return true ; }`

### sentBLEU=0.3
**pred:** `String function ( ) { return getAbsolutePath ( ) ; }`

**ref:**  `String function ( ) { final VirtualFile loc0 = _parent . get ( ) ; if ( loc0 == null || loc0 . getParent ( ) == null ) return "srini_string" ; else { final String loc1 = loc0 . getUnixPathWithoutContainer ( ) ; if ( loc1 . isEmpty ( ) ) return getName ( ) ; else return loc1 + VIRTUAL_FILE_SEPARATOR `

### sentBLEU=0.3
**pred:** `boolean function ( ) { return false ; }`

**ref:**  `boolean function ( ) { try { Class . forName ( "srini_string" ) ; ServiceManager . lookup ( "srini_string" ) ; Log . info ( "srini_string" ) ; } catch ( Exception loc0 ) { Log . info ( "srini_string" ) ; return false ; } return true ; }`

### sentBLEU=0.4
**pred:** `int function ( ) { return numShards ; }`

**ref:**  `int function ( ShardRoutingState ... arg0 ) { int loc0 = 0 ; for ( MutableShardRouting loc1 : this ) { for ( ShardRoutingState loc2 : arg0 ) { if ( loc1 . loc2 ( ) == loc2 ) { loc0 ++ ; } } } return loc0 ; }`

### sentBLEU=0.4
**pred:** `boolean function ( String arg0 ) { return ( arg0 . startsWith ( "srini_string" ) ) ; }`

**ref:**  `void function ( Run < ? , ? > arg0 , SCM arg1 , TaskListener arg2 , ChangeLogSet < ? > arg3 ) { if ( arg0 instanceof AbstractBuild && arg2 instanceof BuildListener && Util . isOverridden ( SCMListener . class , getClass ( ) , "srini_string" , AbstractBuild . class , BuildListener . class , ChangeLog`

### sentBLEU=0.4
**pred:** `int function ( int arg0 ) { return arg0 < 0 ? - 1 : arg0 ; }`

**ref:**  `int function ( Viewer arg0 , Object arg1 , Object arg2 ) { int loc0 = category ( arg1 ) ; int loc1 = category ( arg2 ) ; if ( loc0 != loc1 ) { return loc0 - loc1 ; } String loc2 = getLabel ( arg0 , arg1 ) ; String loc3 = getLabel ( arg0 , arg2 ) ; return getComparator ( ) . compare ( loc2 , loc3 ) ;`
